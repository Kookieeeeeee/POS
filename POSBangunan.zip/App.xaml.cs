﻿using POSBangunan.Database;
using POSBangunan.Services.Auth;
using POSBangunan.Services.Logging;
using POSBangunan.Views;
using System.Windows;
using System.Windows.Threading;

namespace POSBangunan;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Inisialisasi Database
        try
        {
            DatabaseInitializer.Initialize();

            AuthService auth = new();

            auth.EnsureDefaultAdmin();

            DispatcherUnhandledException += App_DispatcherUnhandledException;

            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;

            LogService.Info("Application Started");

            LoginWindow login = new();

            MainWindow = login;

            login.Show();
        }
        catch (Exception ex)
        {
            Exception real = ex;

            while (real.InnerException != null)
                real = real.InnerException;

            MessageBox.Show(
                real.ToString(),
                "Database Error");
        }

        // UI Thread
        DispatcherUnhandledException +=
            App_DispatcherUnhandledException;

        // Background Thread
        AppDomain.CurrentDomain.UnhandledException +=
            CurrentDomain_UnhandledException;

        // Async Task
        TaskScheduler.UnobservedTaskException +=
            TaskScheduler_UnobservedTaskException;
    }

    private void App_DispatcherUnhandledException(
        object sender,
        DispatcherUnhandledExceptionEventArgs e)
    {
        LogService.Exception(e.Exception);

        MessageBox.Show(
            "Terjadi kesalahan yang tidak terduga.\n\n" +
            e.Exception.Message,
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Error);

        e.Handled = true;
    }

    private void CurrentDomain_UnhandledException(
        object? sender,
        UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
        {
            LogService.Exception(ex);
        }
    }

    private void TaskScheduler_UnobservedTaskException(
        object? sender,
        UnobservedTaskExceptionEventArgs e)
    {
        LogService.Exception(e.Exception);

        e.SetObserved();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        LogService.Info("Application Closed");

        base.OnExit(e);
    }
}