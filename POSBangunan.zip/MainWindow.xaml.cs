﻿using POSBangunan.Services.Auth;
using POSBangunan.Services.Sync;
using POSBangunan.Services.Navigation;
using POSBangunan.Views;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POSBangunan;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        NavigationService.Initialize(MainContent);

        PermissionService.Apply(this);

        NavigationService.Navigate(new DashboardView());
    }
    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {

    }

    private void BtnDashboard_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new DashboardView());
    }

    private void BtnBarang_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new BarangView());
    }

    private void BtnPenjualan_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new PenjualanView());
    }
    private void BtnRiwayat_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new HistoryView());
    }
    private void BtnLaporan_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new LaporanView());
    }

    private void BtnPengaturan_Click(object sender, RoutedEventArgs e)
    {
        NavigationService.Navigate(new SettingsView());
    }
}