﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows;

namespace POSBangunan.Views;

public partial class LoadingWindow : Window
{
    public LoadingWindow()
    {
        InitializeComponent();
    }

    public LoadingWindow(string title, string message)
    {
        InitializeComponent();

        SetTitle(title);

        SetMessage(message);
    }

    public void SetTitle(string title)
    {
        Dispatcher.Invoke(() =>
        {
            TxtTitle.Text = title;
        });
    }

    public void SetMessage(string message)
    {
        Dispatcher.Invoke(() =>
        {
            TxtMessage.Text = message;
        });
    }

    public void Update(string title, string message)
    {
        Dispatcher.Invoke(() =>
        {
            TxtTitle.Text = title;
            TxtMessage.Text = message;
        });
    }

    public void CloseLoading()
    {
        Dispatcher.Invoke(() =>
        {
            Close();
        });
    }
}