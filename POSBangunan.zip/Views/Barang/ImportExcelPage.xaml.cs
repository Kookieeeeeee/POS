﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using POSBangunan.Services.Import;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views.Barang;

public partial class ImportExcelPage : Page
{
    private string _file = "";

    public ImportExcelPage()
    {
        InitializeComponent();
    }

    private void BtnBrowse_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog dialog = new();

        dialog.Filter =
            "Excel (*.xlsx)|*.xlsx";

        if (dialog.ShowDialog() != true)
            return;

        _file = dialog.FileName;

        TxtFile.Text = _file;

        ExcelImportService service = new();

        GridPreview.ItemsSource =
            service.Preview(_file).DefaultView;
    }

    private async void BtnImport_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_file))
        {
            MessageBox.Show("Pilih file Excel terlebih dahulu.");
            return;
        }

        BtnImport.IsEnabled = false;

        ProgressImport.IsIndeterminate = true;

        TxtStatus.Text = "Import sedang berjalan...";

        try
        {
            ExcelImportService service = new();

            var result =
                await service.ImportAsync(_file);

            TxtStatus.Text =
                $"Berhasil : {result.Success}   Gagal : {result.Failed}";

            MessageBox.Show(
                $"Import selesai.\n\nBerhasil : {result.Success}\nGagal : {result.Failed}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }

        ProgressImport.IsIndeterminate = false;

        BtnImport.IsEnabled = true;
    }
}