﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using POSBangunan.Models;
using POSBangunan.Services.Dashboard;
using System;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class DashboardView : UserControl
{
    private readonly DashboardService _dashboardService = new();

    public DashboardView()
    {
        InitializeComponent();

        LoadDashboard();
    }

    private void LoadDashboard()
    {
        DashboardSummary data =
            _dashboardService.GetSummary();

        // Card
        TxtTotalBarang.Text =
            data.TotalProduct.ToString();

        TxtLowStock.Text =
            data.LowStock.ToString();

        TxtSQLite.Text =
            data.TotalProduct.ToString();

        TxtCloud.Text =
            data.CloudConnected
                ? data.CloudProduct.ToString()
                : "Offline";

        // Cloud
        TxtCloudStatus.Text =
            data.CloudConnected
                ? "🟢 Online"
                : "🔴 Offline";

        TxtLastSync.Text =
            data.LastSync.ToString("dd MMM yyyy HH:mm");
    }
}