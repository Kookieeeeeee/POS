﻿using POSBangunan.Core;
using System.Windows;

namespace POSBangunan.Views;

public partial class AboutWindow : Window
{
    public AboutWindow()
    {
        InitializeComponent();

        Loaded += AboutWindow_Loaded;
    }

    private void AboutWindow_Loaded(object sender, RoutedEventArgs e)
    {
        TxtAppName.Text =
            VersionInfo.AppName;

        TxtVersion.Text =
            $"Version {VersionInfo.Version}";

        TxtDeveloper.Text =
            VersionInfo.Developer;

        TxtUniversity.Text =
            VersionInfo.University;

        TxtFramework.Text =
            VersionInfo.Framework;

        TxtDatabase.Text =
            VersionInfo.Database;

        TxtCloud.Text =
            VersionInfo.Cloud;

        TxtBuild.Text =
            VersionInfo.Build;
    }

    private void BtnOk_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}