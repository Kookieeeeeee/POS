﻿using POSBangunan.Models;
using POSBangunan.Services.Printing;
using System;
using System.Windows;

namespace POSBangunan.Views;

public partial class PrintReceiptWindow : Window
{
    private readonly Order _order;
    private readonly ReceiptPrinterService _printer = new();

    public PrintReceiptWindow(Order order)
    {
        InitializeComponent();

        _order = order;

        TxtInvoice.Text = order.InvoiceNumber;
    }

    private void BtnPrint_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.Print(_order);

            MessageBox.Show(
                "Struk berhasil dicetak.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            DialogResult = true;

            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Gagal mencetak struk.\n\n" + ex.Message,
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}