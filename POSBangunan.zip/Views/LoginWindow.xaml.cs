﻿using POSBangunan.Models;
using POSBangunan.Services.Auth;
using POSBangunan.Services.Dialog;
using System.Windows;
using System.Windows.Input;

namespace POSBangunan.Views;

public partial class LoginWindow : Window
{
    private readonly AuthService _auth = new();

    public LoginWindow()
    {
        InitializeComponent();

        Loaded += LoginWindow_Loaded;

        TxtUsername.KeyDown += Input_KeyDown;
        TxtPassword.KeyDown += Input_KeyDown;
    }

    private void LoginWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _auth.EnsureDefaultAdmin();

        TxtUsername.Focus();
    }

    private void Input_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            DoLogin();
        }
    }

    private void BtnLogin_Click(object sender, RoutedEventArgs e)
    {
        DoLogin();
    }

    private void DoLogin()
    {
        string username = TxtUsername.Text.Trim();

        string password = TxtPassword.Password;

        if (string.IsNullOrWhiteSpace(username))
        {
            DialogService.Warning(
                "Username harus diisi.");

            TxtUsername.Focus();

            return;
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            DialogService.Warning(
                "Password harus diisi.");

            TxtPassword.Focus();

            return;
        }

        User? user =
            _auth.Login(username, password);

        if (user == null)
        {
            DialogService.Error(
                "Username atau password salah.");

            TxtPassword.Clear();

            TxtPassword.Focus();

            return;
        }

        SessionManager.Login(user);

        MainWindow main = new();

        Application.Current.MainWindow = main;

        main.Show();

        Close();
    }
}