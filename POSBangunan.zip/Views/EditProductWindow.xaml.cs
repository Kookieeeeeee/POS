﻿using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services;
using System.Linq;
using System.Windows;

namespace POSBangunan.Views;

public partial class EditProductWindow : Window
{
    private Product _product;

    public EditProductWindow(Product product)
    {
        InitializeComponent();

        _product = product;

        LoadCategories();

        TxtCode.Text = product.Code;
        TxtName.Text = product.Name;
        CbCategory.Text = product.Category;
        TxtBuyPrice.Text = product.BuyPrice.ToString();
        TxtSellPrice.Text = product.SellPrice.ToString();
        TxtStock.Text = product.Stock.ToString();
    }

    private void LoadCategories()
    {
        using var db = new AppDbContext();

        CbCategory.ItemsSource = db.Categories
                                   .OrderBy(x => x.Name)
                                   .ToList();
    }

    private async void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        ProductService service = new();

        if (service.CodeExists(
            TxtCode.Text.Trim(),
            _product.Id))
        {
            MessageBox.Show(
                "Kode barang sudah digunakan.");

            return;
        }
        using var db = new AppDbContext();

        string categoryName = CbCategory.Text.Trim();

        var category = db.Categories
                         .FirstOrDefault(x => x.Name == categoryName);

        if (category == null)
        {
            category = new Category
            {
                Name = categoryName
            };

            db.Categories.Add(category);
            db.SaveChanges();
        }

        _product.Code = TxtCode.Text;
        _product.Name = TxtName.Text;
        _product.Category = category.Name;
        _product.BuyPrice = decimal.Parse(TxtBuyPrice.Text);
        _product.SellPrice = decimal.Parse(TxtSellPrice.Text);
        _product.Stock = decimal.Parse(TxtStock.Text);

        await service.UpdateAsync(_product);

        DialogResult = true;
        Close();
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}