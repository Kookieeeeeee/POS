﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using POSBangunan.Services.Backup;
using System;
using System.IO;
using System.Windows;

namespace POSBangunan.Views;

public partial class BackupWindow : Window
{
    private readonly BackupService _backupService = new();

    public BackupWindow()
    {
        InitializeComponent();

        LoadInformation();
    }

    private void LoadInformation()
    {
        TxtDatabasePath.Text =
            _backupService.GetDatabasePath();

        TxtLastBackup.Text = "-";
    }

    private void BtnBackup_Click(object sender, RoutedEventArgs e)
    {
        SaveFileDialog dialog = new()
        {
            Filter = "SQLite Database (*.db)|*.db",
            FileName = _backupService.GetDefaultBackupName()
        };

        if (dialog.ShowDialog() != true)
            return;

        bool success =
            _backupService.Backup(dialog.FileName);

        if (!success)
        {
            MessageBox.Show(
                "Backup database gagal.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return;
        }

        TxtLastBackup.Text =
            DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

        MessageBox.Show(
            $"Backup berhasil.\n\n{dialog.FileName}",
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void BtnRestore_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog dialog = new()
        {
            Filter = "SQLite Database (*.db)|*.db"
        };

        if (dialog.ShowDialog() != true)
            return;

        MessageBoxResult result =
            MessageBox.Show(
                "Restore database akan mengganti seluruh data saat ini.\n\nLanjutkan?",
                "Konfirmasi Restore",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

        if (result != MessageBoxResult.Yes)
            return;

        bool success =
            _backupService.Restore(dialog.FileName);

        if (!success)
        {
            MessageBox.Show(
                "Restore database gagal.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return;
        }

        MessageBox.Show(
            "Restore berhasil.\n\nSilakan tutup dan buka kembali aplikasi.",
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        Close();
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}