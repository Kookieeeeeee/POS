﻿using Microsoft.Win32;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using POSBangunan.Services.Sync;

namespace POSBangunan.Views;

public partial class AddProductWindow : Window
{
    private readonly ProductService _productService = new();

    private string _selectedImagePath = "";

    public AddProductWindow()
    {
        InitializeComponent();

        LoadCategories();

        CbUnit.SelectedIndex = 0;

        TxtMinimumStock.Text = "5";

        CbCategory.SelectionChanged += CbCategory_SelectionChanged;
    }
    private void LoadCategories()
    {
        using var db = new AppDbContext();

        CbCategory.ItemsSource = db.Categories
            .OrderBy(x => x.Name)
            .ToList();

        CbCategory.DisplayMemberPath = "Name";
    }


    private void CbCategory_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (CbCategory.SelectedItem is Category category)
        {
            TxtCode.Text = _productService.GenerateCode(category.Name);
        }
    }

    private void BtnBrowse_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog dialog = new();

        dialog.Filter = "Image|*.jpg;*.jpeg;*.png;*.bmp;*.webp";

        if (dialog.ShowDialog() != true)
            return;

        _selectedImagePath = dialog.FileName;

        ImgPreview.Source = new BitmapImage(new Uri(_selectedImagePath));

        TxtNoImage.Visibility = Visibility.Collapsed;
    }

    private async void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (!ValidateInput())
            return;

        using var db = new AppDbContext();

        string categoryName = CbCategory.Text.Trim();

        var category = db.Categories
            .FirstOrDefault(x => x.Name == categoryName);

        if (category == null)
        {
            category = new Category
            {
                Name = categoryName
            };

            db.Categories.Add(category);

            db.SaveChanges();
        }

        string imagePath = SaveImage();

        Product product = new()
        {
            Code = TxtCode.Text.Trim(),

            Name = ToTitleCase(TxtName.Text.Trim()),

            Category = category.Name,

            Unit = CbUnit.Text,

            BuyPrice = decimal.Parse(
                TxtBuyPrice.Text,
                CultureInfo.InvariantCulture),

            SellPrice = decimal.Parse(
                TxtSellPrice.Text,
                CultureInfo.InvariantCulture),

            Stock = decimal.Parse(
                TxtStock.Text,
                CultureInfo.InvariantCulture),

            MinimumStock = decimal.Parse(
                TxtMinimumStock.Text,
                CultureInfo.InvariantCulture),

            ImagePath = imagePath
        };

        ProductService service = new();

        await service.AddAsync(product);

        MessageBox.Show(
            "Barang berhasil disimpan.",
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        DialogResult = true;
        Close();
    }

    private bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(TxtCode.Text))
        {
            MessageBox.Show("Kode barang belum dibuat.");
            return false;
        }

        if (_productService.CodeExists(TxtCode.Text.Trim()))
        {
            MessageBox.Show("Kode barang sudah digunakan.");
            return false;
        }

        if (string.IsNullOrWhiteSpace(TxtName.Text))
        {
            MessageBox.Show("Nama barang wajib diisi.");
            return false;
        }

        if (string.IsNullOrWhiteSpace(CbCategory.Text))
        {
            MessageBox.Show("Kategori wajib dipilih.");
            return false;
        }

        if (!decimal.TryParse(TxtBuyPrice.Text, out _))
        {
            MessageBox.Show("Harga beli tidak valid.");
            return false;
        }

        if (!decimal.TryParse(TxtSellPrice.Text, out _))
        {
            MessageBox.Show("Harga jual tidak valid.");
            return false;
        }

        if (!decimal.TryParse(TxtStock.Text, out _))
        {
            MessageBox.Show("Stock tidak valid.");
            return false;
        }

        if (!decimal.TryParse(TxtMinimumStock.Text, out _))
        {
            MessageBox.Show("Minimum stock tidak valid.");
            return false;
        }

        return true;
    }

    private string SaveImage()
    {
        if (string.IsNullOrWhiteSpace(_selectedImagePath))
            return "";

        string folder = Path.Combine(
            AppContext.BaseDirectory,
            "Assets",
            "Products");

        Directory.CreateDirectory(folder);

        string extension = Path.GetExtension(_selectedImagePath);

        string fileName = TxtCode.Text.Trim() + extension;

        string destination = Path.Combine(folder, fileName);

        File.Copy(_selectedImagePath, destination, true);

        return destination;
    }

    private string ToTitleCase(string text)
    {
        TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;

        return textInfo.ToTitleCase(text.ToLower());
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}