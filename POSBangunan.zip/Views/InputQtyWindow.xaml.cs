﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using POSBangunan.Models;
using System.Globalization;
using System.Windows;
using System.Windows.Input;

namespace POSBangunan.Views;

public partial class InputQtyWindow : Window
{
    public decimal Qty { get; private set; }

    private readonly Product _product;

    public InputQtyWindow(Product product)
    {
        InitializeComponent();

        _product = product;

        TxtProduct.Text = product.Name;

        TxtStock.Text =
            $"Stock : {product.Stock:0.##} {product.Unit}";

        TxtQty.Text = "1";

        Loaded += (_, __) =>
        {
            TxtQty.Focus();
            TxtQty.SelectAll();
        };
    }

    private void BtnOk_Click(object sender, RoutedEventArgs e)
    {
        Save();
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }

    private void TxtQty_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            Save();
            return;
        }

        if (e.Key == Key.Escape)
        {
            DialogResult = false;
        }
    }

    private void Save()
    {
        string value = TxtQty.Text.Trim().Replace(",", ".");

        if (!decimal.TryParse(
            value,
            NumberStyles.Any,
            CultureInfo.InvariantCulture,
            out decimal qty))
        {
            MessageBox.Show(
                "Jumlah tidak valid.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        if (qty <= 0)
        {
            MessageBox.Show(
                "Jumlah harus lebih dari 0.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        // Barang non-meteran wajib bilangan bulat
        if (!_product.IsDecimalUnit && qty % 1 != 0)
        {
            MessageBox.Show(
                $"Barang dengan satuan {_product.Unit} tidak boleh menggunakan angka desimal.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        // Cek stok
        if (qty > _product.Stock)
        {
            MessageBox.Show(
                "Qty melebihi stok tersedia.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        Qty = qty;

        DialogResult = true;
    }
}