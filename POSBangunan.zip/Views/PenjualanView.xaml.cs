﻿using POSBangunan.Models;
using POSBangunan.Services;
using POSBangunan.Views.Components;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace POSBangunan.Views;

public partial class PenjualanView : UserControl
{
    private readonly CartService _cart = new();
    private List<Product> _filteredProducts = new();

    public PenjualanView()
    {
        InitializeComponent();

        LvCart.ItemsSource = _cart.Items;

        LoadProducts();

        RefreshCart();
    }

    private void LoadProducts()
    {
        ProductService service = new();

        _filteredProducts = service.GetAll();

        ShowProducts(_filteredProducts);
    }

    private void ShowProducts(List<Product> products)
    {
        WpProducts.Children.Clear();

        foreach (var product in products)
        {
            ProductCard card = new(product);

            card.AddClicked += ProductDipilih;

            WpProducts.Children.Add(card);
        }
    }

    private void ProductDipilih(Product product)
    {
        if (product.IsDecimalUnit)
        {
            InputQtyWindow window = new(product);

            window.Owner = Window.GetWindow(this);

            if (window.ShowDialog() != true)
                return;

            _cart.Add(product, window.Qty);
        }
        else
        {
            _cart.Add(product, 1);
        }

        RefreshCart();
    }

    private void RefreshCart()
    {
        LvCart.Items.Refresh();

        TxtTotal.Text = $"Rp {_cart.Total():N0}";

        if (TxtItemCount != null)
            TxtItemCount.Text = $"{_cart.TotalItem():0.##} Item";
    }

    private void BtnPlus_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not Product product)
            return;

        _cart.Increase(product);

        RefreshCart();
    }

    private void BtnMinus_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not Product product)
            return;

        _cart.Decrease(product);

        RefreshCart();
    }

    private void BtnRemove_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not Product product)
            return;

        _cart.Remove(product);

        RefreshCart();
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        ProductService service = new();

        _filteredProducts =
            service.Search(TxtSearch.Text.Trim());

        ShowProducts(_filteredProducts);
    }

    private void TxtSearch_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter)
            return;

        if (_filteredProducts.Count == 0)
            return;

        ProductDipilih(_filteredProducts.First());

        TxtSearch.Clear();

        TxtSearch.Focus();
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        if (_cart.Items.Count == 0)
        {
            MessageBox.Show(
                "Keranjang masih kosong.",
                "POS Bangunan",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        try
        {
            OrderService service = new();

            Order order =
                service.CreateOrder(
                    _cart.Items.ToList(),
                    "Admin");

            PrintReceiptWindow print =
                new(order);

            print.Owner =
                Window.GetWindow(this);

            print.ShowDialog();

            _cart.Clear();

            RefreshCart();

            LoadProducts();

            TxtSearch.Focus();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Transaksi Gagal",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}