﻿using POSBangunan.Models;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace POSBangunan.Views.Components;

public partial class ProductCard : UserControl
{
    public Product Product { get; }

    public event Action<Product>? AddClicked;

    public ProductCard(Product product)
    {
        InitializeComponent();

        Product = product;

        LoadProduct();
    }

    private void LoadProduct()
    {
        TxtName.Text = Product.Name;

        TxtCategory.Text = Product.Category;

        TxtPrice.Text = $"Rp {Product.SellPrice:N0}";

        LoadStock();

        LoadImage();

        BtnTambah.Click += BtnTambah_Click;
    }

    private void LoadImage()
    {
        if (string.IsNullOrWhiteSpace(Product.ImagePath))
            return;

        try
        {
            string fullPath = Path.Combine(
                AppContext.BaseDirectory,
                Product.ImagePath);

            if (!File.Exists(fullPath))
                return;

            BitmapImage image = new();

            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.UriSource = new Uri(fullPath);
            image.EndInit();

            ImgProduct.Source = image;

            PanelNoImage.Visibility = Visibility.Collapsed;
        }
        catch
        {
            // Abaikan jika gambar rusak
        }
    }

    private void LoadStock()
    {
        if (Product.Stock <= 0)
        {
            TxtStock.Text = "Stok Habis";

            BdStock.Background = Brushes.IndianRed;

            TxtStock.Foreground = Brushes.White;

            BtnTambah.Content = "Habis";

            BtnTambah.IsEnabled = false;

            return;
        }

        TxtStock.Text = $"Stock : {Product.Stock}";

        if (Product.Stock <= Product.MinimumStock)
        {
            BdStock.Background =
                new SolidColorBrush(Color.FromRgb(254, 240, 138));

            TxtStock.Foreground = Brushes.DarkOrange;
        }
        else
        {
            BdStock.Background =
                new SolidColorBrush(Color.FromRgb(220, 252, 231));

            TxtStock.Foreground = Brushes.DarkGreen;
        }
    }

    private void BtnTambah_Click(object sender, RoutedEventArgs e)
    {
        AddClicked?.Invoke(Product);
    }
}