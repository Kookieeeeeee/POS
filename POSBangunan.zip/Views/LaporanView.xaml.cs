﻿using Microsoft.Win32;
using POSBangunan.Services.Reports;
using System;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class LaporanView : UserControl
{
    private readonly ReportService _reportService = new();
    private readonly ExcelReportService _excelService = new();
    private readonly PdfReportService _pdfService = new();

    public LaporanView()
    {
        InitializeComponent();

        DpStart.SelectedDate = new DateTime(
            DateTime.Today.Year,
            DateTime.Today.Month,
            1);

        DpEnd.SelectedDate = DateTime.Today;

        LoadReport();
    }

    private void LoadReport()
    {
        if (DpStart.SelectedDate == null ||
            DpEnd.SelectedDate == null)
            return;

        DateTime start = DpStart.SelectedDate.Value;
        DateTime end = DpEnd.SelectedDate.Value;

        TxtSales.Text =
            $"Rp {_reportService.GetTotalSales(start, end):N0}";

        TxtProfit.Text =
            $"Rp {_reportService.GetTotalProfit(start, end):N0}";

        TxtTransaction.Text =
            _reportService.GetTransactionCount(start, end)
            .ToString();

        TxtQty.Text =
            _reportService.GetTotalQtySold(start, end)
            .ToString("N2");

        GridReport.ItemsSource =
            _reportService.GetOrders(start, end);
    }

    private void BtnLoad_Click(object sender, RoutedEventArgs e)
    {
        LoadReport();
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        DpStart.SelectedDate = new DateTime(
            DateTime.Today.Year,
            DateTime.Today.Month,
            1);

        DpEnd.SelectedDate = DateTime.Today;

        LoadReport();
    }

    private void BtnExportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (DpStart.SelectedDate == null ||
            DpEnd.SelectedDate == null)
            return;

        DateTime start = DpStart.SelectedDate.Value;
        DateTime end = DpEnd.SelectedDate.Value;

        SaveFileDialog dialog = new()
        {
            Filter = "Excel Workbook (*.xlsx)|*.xlsx",
            FileName = $"Laporan_{DateTime.Now:yyyyMMdd}.xlsx"
        };

        if (dialog.ShowDialog() != true)
            return;

        _excelService.Export(
            dialog.FileName,
            _reportService.GetOrders(start, end),
            _reportService.GetTotalSales(start, end),
            _reportService.GetTotalProfit(start, end),
            _reportService.GetTransactionCount(start, end));

        MessageBox.Show(
            "Export Excel berhasil.",
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void BtnExportPdf_Click(object sender, RoutedEventArgs e)
    {
        if (DpStart.SelectedDate == null ||
            DpEnd.SelectedDate == null)
            return;

        DateTime start = DpStart.SelectedDate.Value;
        DateTime end = DpEnd.SelectedDate.Value;

        SaveFileDialog dialog = new()
        {
            Filter = "PDF (*.pdf)|*.pdf",
            FileName = $"Laporan_{DateTime.Now:yyyyMMdd}.pdf"
        };

        if (dialog.ShowDialog() != true)
            return;

        _pdfService.Export(
            dialog.FileName,
            _reportService.GetOrders(start, end),
            _reportService.GetTotalSales(start, end),
            _reportService.GetTotalProfit(start, end),
            _reportService.GetTransactionCount(start, end));

        MessageBox.Show(
            "Export PDF berhasil.",
            "POS Bangunan",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }
}