﻿using POSBangunan.Models;
using POSBangunan.Services.Sync;
using System;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class CloudCenterView : UserControl
{
    private readonly CloudSyncService _service = new();

    public CloudCenterView()
    {
        InitializeComponent();

        Loaded += CloudCenterView_Loaded;
    }

    private async void CloudCenterView_Loaded(object sender, RoutedEventArgs e)
    {
        await RefreshStatus();
    }

    private async Task RefreshStatus()
    {
        try
        {
            AppendLog("Mengambil status cloud...");

            CloudStatus status =
                await _service.GetStatusAsync();

            TxtStatus.Text =
                status.Connected
                    ? "🟢 Online"
                    : "🔴 Offline";

            TxtSQLite.Text =
                $"{status.LocalProduct} Produk\n{status.LocalOrder} Order";

            TxtCloud.Text =
                $"{status.CloudProduct} Produk\n{status.CloudOrder} Order";

            TxtLastSync.Text =
                status.LastSyncText;

            AppendLog("Status berhasil diperbarui.");
        }
        catch (Exception ex)
        {
            AppendLog(ex.Message);
        }
    }

    private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        await RefreshStatus();
    }

    private async void BtnTest_Click(object sender, RoutedEventArgs e)
    {
        AppendLog("Testing koneksi...");

        CloudStatus status =
            await _service.GetStatusAsync();

        if (status.Connected)
        {
            MessageBox.Show(
                "Berhasil terhubung ke Supabase.",
                "Cloud",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            AppendLog("Koneksi berhasil.");
        }
        else
        {
            MessageBox.Show(
                "Tidak dapat terhubung ke Supabase.",
                "Cloud",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            AppendLog("Koneksi gagal.");
        }

        await RefreshStatus();
    }

    private async void BtnUpload_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            AppendLog("Upload dimulai...");

            bool success =
                await _service.UploadAllAsync();

            AppendLog(
                success
                    ? "Upload selesai."
                    : "Upload gagal.");

            await RefreshStatus();
        }
        catch (Exception ex)
        {
            AppendLog(ex.Message);
        }
    }

    private async void BtnDownload_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            AppendLog("Download dimulai...");

            bool success =
                await _service.DownloadAllAsync();

            AppendLog(
                success
                    ? "Download selesai."
                    : "Download gagal.");

            await RefreshStatus();
        }
        catch (Exception ex)
        {
            AppendLog(ex.Message);
        }
    }

    private async void BtnFullSync_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            AppendLog("Full Sync dimulai...");

            bool success =
                await _service.FullSyncAsync();

            AppendLog(
                success
                    ? "Full Sync selesai."
                    : "Full Sync gagal.");

            await RefreshStatus();
        }
        catch (Exception ex)
        {
            AppendLog(ex.Message);
        }
    }

    private void AppendLog(string text)
    {
        TxtLog.AppendText(
            $"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");

        TxtLog.ScrollToEnd();
    }
}