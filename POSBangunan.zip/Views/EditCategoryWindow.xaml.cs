﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using POSBangunan.Services;

namespace POSBangunan.Views;

public partial class EditCategoryWindow : Window
{
    private readonly string _oldName;

    public EditCategoryWindow(string oldName)
    {
        InitializeComponent();

        _oldName = oldName;

        TxtCategory.Text = oldName;
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        CategoryService service = new();

        service.Rename(_oldName, TxtCategory.Text.Trim());

        DialogResult = true;

        Close();
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
