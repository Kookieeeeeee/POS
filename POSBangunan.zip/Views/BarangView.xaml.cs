﻿using POSBangunan.Models;
using POSBangunan.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace POSBangunan.Views;

public partial class BarangView : UserControl
{
    public BarangView()
    {
        InitializeComponent();

        LoadData();
    }

    private void LoadData()
    {
        ProductService service = new ProductService();

        DgBarang.ItemsSource = service.GetAll();
    }

    private void BtnTambah_Click(object sender, RoutedEventArgs e)
    {
        AddProductWindow window = new();

        window.ShowDialog();

        LoadData();
    }

    private void TxtCari_TextChanged(object sender, TextChangedEventArgs e)
    {
        ProductService service = new();

        DgBarang.ItemsSource = service.Search(TxtCari.Text);
    }
    private void BtnEdit_Click(object sender, RoutedEventArgs e)
    {
        Button button = (Button)sender;

        Product product = (Product)button.Tag;

        EditProductWindow window = new EditProductWindow(product);

        if (window.ShowDialog() == true)
        {
            LoadData();
        }
    }

    private async void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        Button button = (Button)sender;

        Product product = (Product)button.Tag;

        MessageBoxResult result = MessageBox.Show(
            $"Hapus barang '{product.Name}'?",
            "Konfirmasi",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (result == MessageBoxResult.Yes)
        {
            ProductService service = new ProductService();

            //await _productService.DeleteAsync(product.Id);

            LoadData();
        }
    }

}
