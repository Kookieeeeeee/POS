﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows;
using POSBangunan.Models;
using POSBangunan.Services.History;

namespace POSBangunan.Views;

public partial class InvoiceDetailWindow : Window
{
    private readonly SalesHistoryService _service = new();

    public InvoiceDetailWindow(Order order)
    {
        InitializeComponent();

        LoadInvoice(order);
    }

    private void LoadInvoice(Order order)
    {
        TxtInvoice.Text = order.InvoiceNumber;

        TxtDate.Text =
            order.Date.ToString("dd MMMM yyyy HH:mm");

        TxtCashier.Text =
            $"Kasir : {order.Cashier}";

        TxtTotal.Text =
            $"Rp {order.Total:N0}";

        DgItems.ItemsSource =
            _service.GetItems(order.Id);
    }

    private void BtnClose_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}