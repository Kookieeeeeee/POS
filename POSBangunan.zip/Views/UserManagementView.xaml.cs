﻿using POSBangunan.Models;
using POSBangunan.Services.Audit;
using POSBangunan.Services.Dialog;
using POSBangunan.Services.UserManagement;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class UserManagementView : UserControl
{
    private readonly UserService _service = new();

    private readonly AuditService _audit = new();

    private List<User> _users = new();

    public UserManagementView()
    {
        InitializeComponent();

        Loaded += UserManagementView_Loaded;
    }

    private void UserManagementView_Loaded(object sender, RoutedEventArgs e)
    {
        LoadData();
    }

    private void LoadData()
    {
        _users = _service.GetAll();

        GridUser.ItemsSource = _users;
    }

    private User? SelectedUser =>
        GridUser.SelectedItem as User;

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        string keyword = TxtSearch.Text.Trim();

        if (string.IsNullOrWhiteSpace(keyword))
        {
            GridUser.ItemsSource = _users;
            return;
        }

        GridUser.ItemsSource =
            _service.Search(keyword);
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        TxtSearch.Clear();

        LoadData();
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        UserFormWindow form = new();

        form.Owner = Window.GetWindow(this);

        form.ShowDialog();

        if (!form.Saved)
            return;

        LoadData();
    }

    private void BtnEdit_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedUser == null)
        {
            DialogService.Warning(
                "Pilih user terlebih dahulu.");

            return;
        }

        UserFormWindow form =
            new(SelectedUser);

        form.Owner =
            Window.GetWindow(this);

        form.ShowDialog();

        if (!form.Saved)
            return;

        LoadData();
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedUser == null)
        {
            DialogService.Warning(
                "Pilih user terlebih dahulu.");

            return;
        }

        if (!DialogService.ConfirmDelete(
            $"user '{SelectedUser.Username}'"))
        {
            return;
        }

        try
        {
            _service.Delete(
                SelectedUser.Id);

            _audit.Log(
                "User",
                "DELETE",
                SelectedUser.Username);

            DialogService.Success(
                "User berhasil dihapus.");

            LoadData();
        }
        catch (System.Exception ex)
        {
            DialogService.Error(
                ex.Message);
        }
    }
}