﻿using POSBangunan.Models;
using POSBangunan.Services.Audit;
using POSBangunan.Services.Dialog;
using POSBangunan.Services.UserManagement;
using System;
using System;
using System.Linq;
using System.Windows;

namespace POSBangunan.Views;

public partial class UserFormWindow : Window
{
    private readonly UserService _service = new();
    private readonly AuditService _audit = new();

    private readonly bool _isEdit;
    private readonly User? _user;

    public bool Saved { get; private set; }

    // Tambah
    public UserFormWindow()
    {
        InitializeComponent();

        _isEdit = false;

        LoadRole();
    }

    // Edit
    public UserFormWindow(User user)
    {
        InitializeComponent();

        _isEdit = true;

        _user = user;

        LoadRole();

        LoadUser();
    }

    private void LoadRole()
    {
        CbRole.ItemsSource =
            Enum.GetValues(typeof(UserRole))
                .Cast<UserRole>();

        CbRole.SelectedIndex = 0;
    }

    private void LoadUser()
    {
        if (_user == null)
            return;

        TxtUsername.Text = _user.Username;

        TxtFullName.Text = _user.FullName;

        ChkActive.IsChecked = _user.IsActive;

        CbRole.SelectedItem = _user.Role;

        // Password dikosongkan
        TxtPassword.Password = "";
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string username =
                TxtUsername.Text.Trim();

            string fullname =
                TxtFullName.Text.Trim();

            string password =
                TxtPassword.Password;

            if (string.IsNullOrWhiteSpace(username))
            {
                DialogService.Warning(
                    "Username wajib diisi.");

                TxtUsername.Focus();

                return;
            }

            if (string.IsNullOrWhiteSpace(fullname))
            {
                DialogService.Warning(
                    "Nama lengkap wajib diisi.");

                TxtFullName.Focus();

                return;
            }

            UserRole role =
                (UserRole)CbRole.SelectedItem;

            if (!_isEdit)
            {
                if (string.IsNullOrWhiteSpace(password))
                {
                    DialogService.Warning(
                        "Password wajib diisi.");

                    TxtPassword.Focus();

                    return;
                }

                _service.Add(
                    username,
                    fullname,
                    password,
                    role);

                _audit.Log(
                    "User",
                    "ADD",
                    username);
            }
            else
            {
                if (_user == null)
                    return;

                _user.Username = username;

                _user.FullName = fullname;

                _user.Role = role;

                _user.IsActive =
                    ChkActive.IsChecked == true;

                _service.Update(_user);

                if (!string.IsNullOrWhiteSpace(password))
                {
                    _service.ResetPassword(
                        _user.Id,
                        password);
                }

                _audit.Log(
                    "User",
                    "EDIT",
                    username);
            }

            Saved = true;

            DialogService.Success(
                "Data user berhasil disimpan.");

            Close();
        }
        catch (Exception ex)
        {
            DialogService.Error(ex.Message);
        }
    }

    private void BtnCancel_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}