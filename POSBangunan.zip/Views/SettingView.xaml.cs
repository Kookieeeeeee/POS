﻿using POSBangunan.Models;
using POSBangunan.Services.Audit;
using POSBangunan.Services.Dialog;
using POSBangunan.Services.Logging;
using POSBangunan.Services.Setting;
using System;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class SettingsView : UserControl
{
    private readonly SettingService _service = new();
    private readonly AuditService _audit = new();

    private AppSetting _setting = new();

    public SettingsView()
    {
        InitializeComponent();

        Loaded += SettingsView_Loaded;
    }

    private void SettingsView_Loaded(object sender, RoutedEventArgs e)
    {
        LoadSetting();
    }

    private void LoadSetting()
    {
        try
        {
            _setting = _service.Get();

            TxtStoreName.Text = _setting.StoreName;

            TxtAddress.Text = _setting.StoreAddress;

            TxtPhone.Text = _setting.StorePhone;

            TxtCashier.Text = _setting.CashierName;

            TxtPrinter.Text = _setting.PrinterName;

            TxtBackupFolder.Text = _setting.BackupFolder;

            ChkCloud.IsChecked = _setting.EnableCloud;

            TxtUrl.Text = _setting.SupabaseUrl;

            TxtApiKey.Password = _setting.SupabaseKey;

            TxtCurrency.Text = _setting.CurrencySymbol;

            ChkDarkMode.IsChecked = _setting.DarkMode;
        }
        catch (Exception ex)
        {
            LogService.Exception(ex);

            DialogService.Error(ex.Message);
        }
    }

    private void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _setting.StoreName = TxtStoreName.Text.Trim();

            _setting.StoreAddress = TxtAddress.Text.Trim();

            _setting.StorePhone = TxtPhone.Text.Trim();

            _setting.CashierName = TxtCashier.Text.Trim();

            _setting.PrinterName = TxtPrinter.Text.Trim();

            _setting.BackupFolder = TxtBackupFolder.Text.Trim();

            _setting.EnableCloud =
                ChkCloud.IsChecked == true;

            _setting.SupabaseUrl =
                TxtUrl.Text.Trim();

            _setting.SupabaseKey =
                TxtApiKey.Password.Trim();

            _setting.CurrencySymbol =
                TxtCurrency.Text.Trim();

            _setting.DarkMode =
                ChkDarkMode.IsChecked == true;

            _service.Save(_setting);

            _audit.Log(
                "Setting",
                "SAVE",
                "Pengaturan aplikasi diperbarui");

            DialogService.Success(
                "Pengaturan berhasil disimpan.");
        }
        catch (Exception ex)
        {
            LogService.Exception(ex);

            DialogService.Error(ex.Message);
        }
    }

    private void BtnReset_Click(object sender, RoutedEventArgs e)
    {
        if (!DialogService.Question(
            "Reset semua pengaturan ke default?"))
            return;

        try
        {
            _service.Reset();

            _audit.Log(
                "Setting",
                "RESET",
                "Pengaturan dikembalikan ke default");

            LoadSetting();

            DialogService.Success(
                "Pengaturan berhasil direset.");
        }
        catch (Exception ex)
        {
            LogService.Exception(ex);

            DialogService.Error(ex.Message);
        }
    }
}