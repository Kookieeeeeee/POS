﻿using POSBangunan.Models;
using POSBangunan.Services.Audit;
using POSBangunan.Services.Auth;
using POSBangunan.Services.Dialog;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Views;

public partial class AuditLogView : UserControl
{
    private readonly AuditService _service = new();

    private List<AuditLog> _logs = new();

    public AuditLogView()
    {
        InitializeComponent();

        Loaded += AuditLogView_Loaded;
    }

    private void AuditLogView_Loaded(object sender, RoutedEventArgs e)
    {
        DpStart.SelectedDate = DateTime.Today;

        DpEnd.SelectedDate = DateTime.Today;

        LoadData();
    }

    private void LoadData()
    {
        _logs = _service.GetAll();

        GridAudit.ItemsSource = _logs;
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        string keyword = TxtSearch.Text.Trim();

        if (string.IsNullOrWhiteSpace(keyword))
        {
            GridAudit.ItemsSource = _logs;

            return;
        }

        GridAudit.ItemsSource =
            _service.Search(keyword);
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        TxtSearch.Clear();

        LoadData();
    }

    private void BtnFilter_Click(object sender, RoutedEventArgs e)
    {
        if (DpStart.SelectedDate == null ||
            DpEnd.SelectedDate == null)
        {
            DialogService.Warning(
                "Silakan pilih rentang tanggal.");

            return;
        }

        DateTime start =
            DpStart.SelectedDate.Value.Date;

        DateTime end =
            DpEnd.SelectedDate.Value.Date
                .AddDays(1)
                .AddSeconds(-1);

        GridAudit.ItemsSource =
            _service.GetByDate(start, end);
    }

    private void BtnClear_Click(object sender, RoutedEventArgs e)
    {
        if (!SessionManager.CanManageSetting())
        {
            DialogService.Warning(
                "Anda tidak memiliki hak akses.");

            return;
        }

        bool confirm =
            DialogService.Question(
                "Semua audit log akan dihapus.\n\nLanjutkan?");

        if (!confirm)
            return;

        _service.Clear();

        LoadData();

        DialogService.Success(
            "Audit log berhasil dibersihkan.");
    }
}