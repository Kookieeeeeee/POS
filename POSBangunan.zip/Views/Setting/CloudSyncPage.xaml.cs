﻿using System;
using System.Windows;
using System.Windows.Controls;
using POSBangunan.Services;
using POSBangunan.Services.Sync;

namespace POSBangunan.Views.Settings;

public partial class CloudSyncPage : Page
{
    private readonly ProductService _productService = new();
    private readonly ProductSyncService _syncService = new();
    private readonly SupabaseService _supabase = new();

    public CloudSyncPage()
    {
        InitializeComponent();
        Loaded += CloudSyncPage_Loaded;
    }

    private async void CloudSyncPage_Loaded(object sender, RoutedEventArgs e)
    {
        await RefreshStatus();
    }

    private async Task RefreshStatus()
    {
        TxtSQLiteCount.Text =
            _productService.TotalProduct().ToString();

        TxtLastSync.Text = "-";

        bool connected =
            await _supabase.TestConnectionAsync();

        TxtStatus.Text =
            connected ? "🟢 Connected" : "🔴 Offline";

        if (connected)
        {
            TxtCloudCount.Text =
                (await _supabase.GetProductCountAsync()).ToString();
        }
        else
        {
            TxtCloudCount.Text = "-";
        }
    }

    private async void BtnTest_Click(object sender, RoutedEventArgs e)
    {
        await RefreshStatus();

        Log("Test koneksi selesai.");
    }

    private async void BtnUpload_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            int total =
                await _syncService.UploadAllAsync();

            await RefreshStatus();

            TxtLastSync.Text =
                DateTime.Now.ToString("dd MMM yyyy HH:mm");

            Log($"Upload selesai ({total} produk).");

            MessageBox.Show(
                $"Upload berhasil.\n\n{total} Produk.",
                "Supabase",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }

    private async void BtnDownload_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            int total =
                await _syncService.DownloadAsync();

            TxtSQLiteCount.Text =
                _productService.TotalProduct().ToString();

            TxtLastSync.Text =
                DateTime.Now.ToString("dd MMM yyyy HH:mm");

            Log($"Download selesai ({total} produk).");

            MessageBox.Show(
                "Download berhasil.",
                "Supabase",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }

    private void Log(string text)
    {
        TxtLog.AppendText(
            $"[{DateTime.Now:HH:mm:ss}] {text}\n");

        TxtLog.ScrollToEnd();
    }
}