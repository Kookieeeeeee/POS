﻿using POSBangunan.Models;
using POSBangunan.Services.History;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace POSBangunan.Views;

public partial class HistoryView : UserControl
{
    private readonly SalesHistoryService _service = new();

    private List<Order> _orders = new();

    public HistoryView()
    {
        InitializeComponent();

        DpStart.SelectedDate = DateTime.Today;
        DpEnd.SelectedDate = DateTime.Today;

        LoadData();
    }

    private void LoadData()
    {
        _orders = _service.GetAll();

        GridHistory.ItemsSource = _orders;
    }

    private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        string keyword = TxtSearch.Text.Trim();

        if (string.IsNullOrWhiteSpace(keyword))
        {
            GridHistory.ItemsSource = _orders;
            return;
        }

        GridHistory.ItemsSource = _service.Search(keyword);
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        TxtSearch.Clear();

        DpStart.SelectedDate = DateTime.Today;
        DpEnd.SelectedDate = DateTime.Today;

        LoadData();
    }

    private void BtnFilter_Click(object sender, RoutedEventArgs e)
    {
        if (DpStart.SelectedDate == null ||
            DpEnd.SelectedDate == null)
            return;

        GridHistory.ItemsSource =
            _service.Filter(
                DpStart.SelectedDate.Value,
                DpEnd.SelectedDate.Value);
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (GridHistory.SelectedItem is not Order order)
        {
            MessageBox.Show("Pilih transaksi terlebih dahulu.");
            return;
        }

        if (MessageBox.Show(
            $"Hapus invoice {order.InvoiceNumber} ?",
            "POS Bangunan",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        if (_service.Delete(order.Id))
        {
            MessageBox.Show("Transaksi berhasil dihapus.");

            LoadData();
        }
        else
        {
            MessageBox.Show("Gagal menghapus transaksi.");
        }
    }

    private void GridHistory_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (GridHistory.SelectedItem is not Order order)
            return;

        InvoiceDetailWindow window = new(order);

        window.Owner = Window.GetWindow(this);

        window.ShowDialog();
    }
}