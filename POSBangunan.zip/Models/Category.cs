﻿using POSBangunan.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace POSBangunan.Models;

public class Category
{
    public int Id { get; set; }

    public string Name { get; set; } = "";

    public DateTime UpdatedAt { get; set; }

    public void Rename(string oldName, string newName)
    {
        using var db = new AppDbContext();

        if (string.IsNullOrWhiteSpace(newName))
            return;

        if (oldName == newName)
            return;

        bool exist = db.Categories.Any(x => x.Name == newName);

        if (exist)
        {
            MessageBox.Show("Kategori sudah ada.");
            return;
        }

        var category = db.Categories
                         .FirstOrDefault(x => x.Name == oldName);

        if (category == null)
            return;

        category.Name = newName;

        var products = db.Products
                         .Where(x => x.Category == oldName)
                         .ToList();

        foreach (var item in products)
        {
            item.Category = newName;
        }

        db.SaveChanges();
    }
}
