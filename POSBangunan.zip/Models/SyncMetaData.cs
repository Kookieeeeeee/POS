﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POSBangunan.Models;

public class SyncMetadata
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string TableName { get; set; } = "";

    public DateTime LastSync { get; set; } =
        DateTime.MinValue;

    public DateTime? LastUpload { get; set; }

    public DateTime? LastDownload { get; set; }

    public bool LastSyncSuccess { get; set; }

    public string LastError { get; set; } = "";
}