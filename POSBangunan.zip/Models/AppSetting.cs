﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POSBangunan.Models;

public class AppSetting
{
    [Key]
    public int Id { get; set; }

    // ==========================
    // TOKO
    // ==========================

    public string StoreName { get; set; } = "POS Bangunan";

    public string StoreAddress { get; set; } = "";

    public string StorePhone { get; set; } = "";

    public string CashierName { get; set; } = "";

    // ==========================
    // PRINT
    // ==========================

    public string PrinterName { get; set; } = "";

    public bool AutoPrint { get; set; } = false;

    public bool PrintLogo { get; set; } = true;

    // ==========================
    // BACKUP
    // ==========================

    public bool AutoBackup { get; set; } = false;

    public string BackupFolder { get; set; } =
        "Backup";

    // ==========================
    // CLOUD
    // ==========================

    public bool EnableCloud { get; set; } = false;

    public string SupabaseUrl { get; set; } = "";

    public string SupabaseKey { get; set; } = "";

    // ==========================
    // APPLICATION
    // ==========================

    public bool DarkMode { get; set; } = false;

    public string Theme { get; set; } = "Light";

    public string CurrencySymbol { get; set; } = "Rp";

    public DateTime LastModified { get; set; } =
        DateTime.Now;
}