﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POSBangunan.Models;

public class AuditLog
{
    [Key]
    public int Id { get; set; }

    public DateTime Time { get; set; } =
        DateTime.Now;

    public string Username { get; set; } = "";

    public string Action { get; set; } = "";

    public string Module { get; set; } = "";

    public string Description { get; set; } = "";

    public string IpAddress { get; set; } = "";

    public string ComputerName { get; set; } =
        Environment.MachineName;
}