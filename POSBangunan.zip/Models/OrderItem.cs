﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace POSBangunan.Models;

public class OrderItem
{
    [Key]
    public int Id { get; set; }

    // Foreign Key
    public int OrderId { get; set; }

    public int ProductId { get; set; }

    // Snapshot data produk saat transaksi
    [Required]
    public string ProductCode { get; set; } = "";

    [Required]
    public string ProductName { get; set; } = "";

    [Required]
    public string Unit { get; set; } = "";

    [Column(TypeName = "decimal(18,2)")]
    public decimal BuyPrice { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal SellPrice { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Qty { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal SubTotal { get; set; }

    // Navigation Property
    public virtual Order? Order { get; set; }
}