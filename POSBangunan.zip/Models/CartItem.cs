﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace POSBangunan.Models;

public class CartItem : INotifyPropertyChanged
{
    public Product Product { get; set; } = null!;

    private decimal _qty = 1;

    public decimal Qty
    {
        get => _qty;
        set
        {
            _qty = value;

            OnPropertyChanged();

            OnPropertyChanged(nameof(SubTotal));
        }
    }

    public decimal SubTotal => Qty * Product.SellPrice;

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged(
        [CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(
            this,
            new PropertyChangedEventArgs(propertyName));
    }
}