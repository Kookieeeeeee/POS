﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POSBangunan.Models;

public class Order
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string InvoiceNumber { get; set; } = "";

    public DateTime Date { get; set; } = DateTime.Now;

    [Required]
    public string Cashier { get; set; } = "";

    public int TotalItem { get; set; }

    public decimal Total { get; set; }

    // Navigation Property
    public virtual ICollection<OrderItem> OrderItems { get; set; }
        = new List<OrderItem>();
}