﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Models;

public class StockMovement
{
    public int Id { get; set; }

    public int ProductId { get; set; }

    public string ProductCode { get; set; } = "";

    public string ProductName { get; set; } = "";

    // IN / OUT / ADJUSTMENT
    public string Type { get; set; } = "";

    public decimal Qty { get; set; }

    public decimal Balance { get; set; }

    public string Reference { get; set; } = "";

    public DateTime Date { get; set; }
}