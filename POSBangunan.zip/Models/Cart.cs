﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace POSBangunan.Models;

public class Cart
{
    public List<CartItem> Items { get; set; } = new();

    public decimal Total
    {
        get
        {
            return Items.Sum(x => x.SubTotal);
        }
    }
}