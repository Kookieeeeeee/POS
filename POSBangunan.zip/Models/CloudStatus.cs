﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Models;

public class CloudStatus
{
    public bool Connected { get; set; }

    public string Status =>
        Connected ? "Online" : "Offline";

    public int LocalProduct { get; set; }

    public int CloudProduct { get; set; }

    public int LocalOrder { get; set; }

    public int CloudOrder { get; set; }

    public int PendingUpload { get; set; }

    public int FailedUpload { get; set; }

    public DateTime? LastSync { get; set; }

    public string LastSyncText =>
        LastSync == null
            ? "-"
            : LastSync.Value.ToString("dd MMM yyyy HH:mm");
}