﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using System.Collections.Generic;

namespace POSBangunan.Models;

public class DashboardSummary
{
    // Barang
    public int TotalProduct { get; set; }

    public int LowStock { get; set; }

    // Hari ini
    public decimal TodaySales { get; set; }

    public int TodayTransaction { get; set; }

    // Bulan ini
    public decimal MonthSales { get; set; }

    public int MonthTransaction { get; set; }

    // Cloud
    public bool CloudConnected { get; set; }

    public int CloudProduct { get; set; }

    public DateTime LastSync { get; set; }

    // Transaksi
    public Order? LastTransaction { get; set; }

    public List<Order> RecentOrders { get; set; } = new();
}