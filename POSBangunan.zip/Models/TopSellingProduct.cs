﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Models;

public class TopSellingProduct
{
    public string Name { get; set; } = "";

    public decimal Qty { get; set; }
}