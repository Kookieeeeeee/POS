﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace POSBangunan.Models;

public class Product
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string Code { get; set; } = "";

    [Required]
    public string Name { get; set; } = "";

    [Required]
    public string Category { get; set; } = "";

    [Required]
    public string Unit { get; set; } = "Pcs";

    [Column(TypeName = "decimal(18,2)")]
    public decimal BuyPrice { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal SellPrice { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Stock { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal MinimumStock { get; set; } = 5;

    public string ImagePath { get; set; } = "";

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    [NotMapped]
    public bool IsDecimalUnit =>
        Unit.Equals("Meter", StringComparison.OrdinalIgnoreCase) ||
        Unit.Equals("Kg", StringComparison.OrdinalIgnoreCase) ||
        Unit.Equals("Liter", StringComparison.OrdinalIgnoreCase);

}