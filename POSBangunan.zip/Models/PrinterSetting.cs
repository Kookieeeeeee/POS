﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POSBangunan.Models;

public class PrinterSetting
{
    [Key]
    public int Id { get; set; }

    public string PrinterName { get; set; } = "";

    // 58 / 80
    public int PaperWidth { get; set; } = 80;

    public bool AutoPrint { get; set; } = true;

    public bool OpenCashDrawer { get; set; } = false;

    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}