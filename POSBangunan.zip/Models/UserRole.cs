﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Models;

public enum UserRole
{
    Admin = 0,

    Owner = 1,

    Cashier = 2
}