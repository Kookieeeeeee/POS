﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Core;

public static class VersionInfo
{
    public const string AppName =
        "POS Bangunan";

    public const string Version =
        "1.0.0";

    public const string Build =
        "2026.07.02";

    public const string Developer =
        "Andico Aji";

    public const string University =
        "Universitas Multimedia Nusantara";

    public const string Database =
        "SQLite";

    public const string Cloud =
        "Supabase";

    public const string Framework =
        ".NET 8 WPF";
}