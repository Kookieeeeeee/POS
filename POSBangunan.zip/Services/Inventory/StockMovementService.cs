﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Inventory;

public class StockMovementService
{
    public void AddMovement(
        Product product,
        string type,
        decimal qty,
        string reference)
    {
        using var db = new AppDbContext();

        StockMovement movement = new()
        {
            ProductId = product.Id,

            ProductCode = product.Code,

            ProductName = product.Name,

            Type = type,

            Qty = qty,

            Balance = product.Stock,

            Reference = reference,

            Date = DateTime.Now
        };

        db.StockMovements.Add(movement);

        db.SaveChanges();
    }

    public List<StockMovement> GetAll()
    {
        using var db = new AppDbContext();

        return db.StockMovements
                 .AsNoTracking()
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public List<StockMovement> GetByProduct(int productId)
    {
        using var db = new AppDbContext();

        return db.StockMovements
                 .AsNoTracking()
                 .Where(x => x.ProductId == productId)
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public List<StockMovement> Search(string keyword)
    {
        using var db = new AppDbContext();

        keyword = keyword.Trim().ToLower();

        return db.StockMovements
                 .AsNoTracking()
                 .Where(x =>
                     x.ProductCode.ToLower().Contains(keyword) ||
                     x.ProductName.ToLower().Contains(keyword))
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public List<StockMovement> Filter(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;

        DateTime until = end.Date.AddDays(1);

        return db.StockMovements
                 .AsNoTracking()
                 .Where(x =>
                     x.Date >= from &&
                     x.Date < until)
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }
}