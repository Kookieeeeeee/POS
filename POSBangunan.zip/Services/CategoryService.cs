﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POSBangunan.Database;
using POSBangunan.Models;
using System.Linq;

namespace POSBangunan.Services;

public class CategoryService
{
    public void Rename(string oldName, string newName)
    {
        using var db = new AppDbContext();

        // Cari kategori lama
        var category = db.Categories
                         .FirstOrDefault(x => x.Name == oldName);

        if (category == null)
            return;

        // Cek apakah nama baru sudah ada
        bool exist = db.Categories.Any(x => x.Name == newName);

        if (exist)
            return;

        // Ubah nama kategori
        category.Name = newName;

        // Update semua produk yang menggunakan kategori tersebut
        var products = db.Products
                         .Where(x => x.Category == oldName)
                         .ToList();

        foreach (var item in products)
        {
            item.Category = newName;
        }

        db.SaveChanges();
    }
}