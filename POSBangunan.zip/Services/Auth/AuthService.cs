﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Auth;

public class AuthService
{
    public void EnsureDefaultAdmin()
    {
        using var db = new AppDbContext();

        if (db.Users.Any())
            return;

        User admin = new()
        {
            Username = "admin",
            FullName = "Administrator",
            PasswordHash = HashPassword("admin123"),
            Role = UserRole.Admin,
            IsActive = true,
            CreatedAt = DateTime.Now
        };

        db.Users.Add(admin);

        db.SaveChanges();
    }

    public User? Login(
        string username,
        string password)
    {
        using var db = new AppDbContext();

        string hash = HashPassword(password);

        User? user = db.Users
            .FirstOrDefault(x =>
                x.Username == username &&
                x.PasswordHash == hash &&
                x.IsActive);

        if (user == null)
            return null;

        user.LastLogin = DateTime.Now;

        db.SaveChanges();

        return user;
    }

    public bool ChangePassword(
        int userId,
        string oldPassword,
        string newPassword)
    {
        using var db = new AppDbContext();

        User? user = db.Users
            .FirstOrDefault(x => x.Id == userId);

        if (user == null)
            return false;

        if (user.PasswordHash != HashPassword(oldPassword))
            return false;

        user.PasswordHash = HashPassword(newPassword);

        db.SaveChanges();

        return true;
    }

    public bool ResetPassword(
        int userId,
        string newPassword)
    {
        using var db = new AppDbContext();

        User? user = db.Users
            .FirstOrDefault(x => x.Id == userId);

        if (user == null)
            return false;

        user.PasswordHash = HashPassword(newPassword);

        db.SaveChanges();

        return true;
    }

    public User? GetUser(int id)
    {
        using var db = new AppDbContext();

        return db.Users
            .AsNoTracking()
            .FirstOrDefault(x => x.Id == id);
    }

    public List<User> GetAll()
    {
        using var db = new AppDbContext();

        return db.Users
            .AsNoTracking()
            .OrderBy(x => x.FullName)
            .ToList();
    }

    public static string HashPassword(string password)
    {
        using SHA256 sha = SHA256.Create();

        byte[] bytes =
            sha.ComputeHash(
                Encoding.UTF8.GetBytes(password));

        StringBuilder sb = new();

        foreach (byte b in bytes)
        {
            sb.Append(b.ToString("x2"));
        }

        return sb.ToString();
    }
}