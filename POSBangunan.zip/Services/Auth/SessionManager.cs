﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POSBangunan.Models;

namespace POSBangunan.Services.Auth;

public static class SessionManager
{
    /// <summary>
    /// User yang sedang login.
    /// Null jika belum login.
    /// </summary>
    public static User? CurrentUser { get; private set; }

    /// <summary>
    /// Apakah ada user yang login.
    /// </summary>
    public static bool IsLoggedIn =>
        CurrentUser != null;

    /// <summary>
    /// Nama lengkap user.
    /// </summary>
    public static string DisplayName =>
        CurrentUser?.FullName ?? "Guest";

    /// <summary>
    /// Username user.
    /// </summary>
    public static string Username =>
        CurrentUser?.Username ?? "";

    /// <summary>
    /// Role user.
    /// </summary>
    public static UserRole Role =>
        CurrentUser?.Role ?? UserRole.Cashier;

    /// <summary>
    /// Login session.
    /// </summary>
    public static void Login(User user)
    {
        CurrentUser = user;
    }

    /// <summary>
    /// Logout session.
    /// </summary>
    public static void Logout()
    {
        CurrentUser = null;
    }

    /// <summary>
    /// Cek apakah user memiliki role tertentu.
    /// </summary>
    public static bool IsInRole(UserRole role)
    {
        if (CurrentUser == null)
            return false;

        return CurrentUser.Role == role;
    }

    /// <summary>
    /// Admin atau Owner.
    /// </summary>
    public static bool CanManageProduct()
    {
        return IsInRole(UserRole.Admin)
            || IsInRole(UserRole.Owner);
    }

    /// <summary>
    /// Admin saja.
    /// </summary>
    public static bool CanManageSetting()
    {
        return IsInRole(UserRole.Admin);
    }

    /// <summary>
    /// Admin atau Kasir.
    /// </summary>
    public static bool CanSell()
    {
        return IsInRole(UserRole.Admin)
            || IsInRole(UserRole.Cashier);
    }

    /// <summary>
    /// Semua role boleh melihat laporan.
    /// </summary>
    public static bool CanViewReport()
    {
        return CurrentUser != null;
    }

    /// <summary>
    /// Admin dan Owner boleh backup.
    /// </summary>
    public static bool CanBackup()
    {
        return IsInRole(UserRole.Admin)
            || IsInRole(UserRole.Owner);
    }

    /// <summary>
    /// Admin saja boleh Cloud Sync.
    /// </summary>
    public static bool CanCloudSync()
    {
        return IsInRole(UserRole.Admin);
    }
}