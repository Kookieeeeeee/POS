﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace POSBangunan.Services.Auth;

public static class PermissionService
{
    public static void Apply(MainWindow window)
    {
        // Dashboard
        window.BtnDashboard.Visibility =
            Visibility.Visible;

        // Barang
        window.BtnBarang.Visibility =
            SessionManager.CanManageProduct()
            ? Visibility.Visible
            : Visibility.Collapsed;

        // Penjualan
        window.BtnPenjualan.Visibility =
            SessionManager.CanSell()
            ? Visibility.Visible
            : Visibility.Collapsed;

        // Riwayat
        window.BtnRiwayat.Visibility =
            SessionManager.CanViewReport()
            ? Visibility.Visible
            : Visibility.Collapsed;

        // Laporan
        window.BtnLaporan.Visibility =
            SessionManager.CanViewReport()
            ? Visibility.Visible
            : Visibility.Collapsed;

        // Pengaturan
        window.BtnPengaturan.Visibility =
            SessionManager.CanManageSetting()
            ? Visibility.Visible
            : Visibility.Collapsed;
    }
}