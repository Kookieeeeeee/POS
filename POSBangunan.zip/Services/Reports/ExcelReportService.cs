﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClosedXML.Excel;
using POSBangunan.Models;

namespace POSBangunan.Services.Reports;

public class ExcelReportService
{
    public void Export(
        string filePath,
        IEnumerable<Order> orders,
        decimal totalSales,
        decimal totalProfit,
        int totalTransaction)
    {
        using XLWorkbook workbook = new();

        var ws = workbook.Worksheets.Add("Laporan");

        int row = 1;

        ws.Cell(row, 1).Value = "LAPORAN PENJUALAN";
        ws.Cell(row, 1).Style.Font.Bold = true;
        ws.Cell(row, 1).Style.Font.FontSize = 18;

        row += 2;

        ws.Cell(row, 1).Value = "Invoice";
        ws.Cell(row, 2).Value = "Tanggal";
        ws.Cell(row, 4).Value = "Item";
        ws.Cell(row, 5).Value = "Total";

        ws.Range(row, 1, row, 5)
            .Style.Font.Bold = true;

        row++;

        foreach (var order in orders)
        {
            ws.Cell(row, 1).Value = order.InvoiceNumber;
            ws.Cell(row, 2).Value = order.Date;
            ws.Cell(row, 2).Style.DateFormat.Format = "dd/MM/yyyy HH:mm";

            ws.Cell(row, 4).Value = order.TotalItem;
            ws.Cell(row, 5).Value = order.Total;
            ws.Cell(row, 5).Style.NumberFormat.Format = "#,##0";

            row++;
        }

        row += 2;

        ws.Cell(row, 1).Value = "Total Penjualan";
        ws.Cell(row, 2).Value = totalSales;
        ws.Cell(row, 2).Style.NumberFormat.Format = "#,##0";

        row++;

        ws.Cell(row, 1).Value = "Total Profit";
        ws.Cell(row, 2).Value = totalProfit;
        ws.Cell(row, 2).Style.NumberFormat.Format = "#,##0";

        row++;

        ws.Cell(row, 1).Value = "Jumlah Transaksi";
        ws.Cell(row, 2).Value = totalTransaction;

        ws.Columns().AdjustToContents();

        workbook.SaveAs(filePath);
    }
}