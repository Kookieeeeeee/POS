﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POSBangunan.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace POSBangunan.Services.Reports;

public class PdfReportService
{
    public void Export(
        string filePath,
        IEnumerable<Order> orders,
        decimal totalSales,
        decimal totalProfit,
        int totalTransaction)
    {
        QuestPDF.Settings.License =
            LicenseType.Community;

        Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Margin(30);

                page.Header()
                    .Column(column =>
                    {
                        column.Item().Text("TB BINTANG REZEKI")
                            .FontSize(20)
                            .Bold();

                        column.Item().Text("Laporan Penjualan")
                            .FontSize(16);

                        column.Item().Text(
                            DateTime.Now.ToString(
                                "dd MMMM yyyy HH:mm"));
                    });

                page.Content()
                    .Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.ConstantColumn(120);
                            columns.RelativeColumn();
                            columns.ConstantColumn(80);
                            columns.ConstantColumn(100);
                        });

                        table.Header(header =>
                        {
                            header.Cell().Text("Invoice").Bold();
                            header.Cell().Text("Tanggal").Bold();
                            header.Cell().Text("Item").Bold();
                            header.Cell().Text("Total").Bold();
                        });

                        foreach (var order in orders)
                        {
                            table.Cell().Text(order.InvoiceNumber);

                            table.Cell().Text(
                                order.Date.ToString(
                                    "dd/MM/yyyy"));

                            table.Cell().Text(
                                order.TotalItem.ToString());

                            table.Cell().Text(
                                $"Rp {order.Total:N0}");
                        }
                    });

                page.Footer()
                    .Column(column =>
                    {
                        column.Item().PaddingTop(15);

                        column.Item().Text(
                            $"Total Penjualan : Rp {totalSales:N0}");

                        column.Item().Text(
                            $"Total Profit : Rp {totalProfit:N0}");

                        column.Item().Text(
                            $"Jumlah Transaksi : {totalTransaction}");

                        column.Item().PaddingTop(10);

                        column.Item().AlignCenter()
                            .Text("POS Bangunan")
                            .FontSize(10)
                            .FontColor(Colors.Grey.Medium);
                    });
            });
        })
        .GeneratePdf(filePath);
    }
}