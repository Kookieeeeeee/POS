﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Reports;

public class ReportService
{
    public List<Order> GetOrders(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.Orders
            .AsNoTracking()
            .Where(x => x.Date >= from && x.Date < until)
            .OrderByDescending(x => x.Date)
            .ToList();
    }

    public decimal GetTotalSales(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.Orders
            .Where(x => x.Date >= from && x.Date < until)
            .AsEnumerable()
            .Sum(x => x.Total);
    }

    public int GetTransactionCount(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.Orders.Count(x =>
            x.Date >= from &&
            x.Date < until);
    }

    public decimal GetTotalQtySold(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.OrderItems
            .Include(x => x.Order)
            .Where(x =>
                x.Order != null &&
                x.Order.Date >= from &&
                x.Order.Date < until)
            .AsEnumerable()
            .Sum(x => x.Qty);
    }

    public decimal GetTotalProfit(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.OrderItems
            .Include(x => x.Order)
            .Where(x =>
                x.Order != null &&
                x.Order.Date >= from &&
                x.Order.Date < until)
            .AsEnumerable()
            .Sum(x => (x.SellPrice - x.BuyPrice) * x.Qty);
    }

    public List<OrderItem> GetTopProducts(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.OrderItems
            .Include(x => x.Order)
            .Where(x =>
                x.Order != null &&
                x.Order.Date >= from &&
                x.Order.Date < until)
            .GroupBy(x => new
            {
                x.ProductId,
                x.ProductName
            })
            .Select(g => new OrderItem
            {
                ProductId = g.Key.ProductId,
                ProductName = g.Key.ProductName,
                Qty = g.Sum(x => x.Qty),
                SubTotal = g.Sum(x => x.SubTotal)
            })
            .OrderByDescending(x => x.Qty)
            .Take(10)
            .ToList();
    }
}