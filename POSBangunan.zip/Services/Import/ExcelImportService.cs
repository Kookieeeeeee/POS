﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClosedXML.Excel;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.Sync;
using System.Data;

namespace POSBangunan.Services.Import;

public class ExcelImportService
{
    public DataTable Preview(string filePath)
    {
        DataTable table = new();

        table.Columns.Add("Code");
        table.Columns.Add("Name");
        table.Columns.Add("Category");
        table.Columns.Add("Unit");
        table.Columns.Add("BuyPrice");
        table.Columns.Add("SellPrice");
        table.Columns.Add("Stock");
        table.Columns.Add("MinimumStock");

        using var workbook = new XLWorkbook(filePath);

        var ws = workbook.Worksheet(1);

        foreach (var row in ws.RowsUsed().Skip(1))
        {
            table.Rows.Add(

                row.Cell(1).GetString(),

                row.Cell(2).GetString(),

                row.Cell(3).GetString(),

                row.Cell(4).GetString(),

                row.Cell(5).GetValue<decimal>(),

                row.Cell(6).GetValue<decimal>(),

                row.Cell(7).GetValue<decimal>(),

                row.Cell(8).GetValue<decimal>()

            );
        }

        return table;
    }

    public async Task<ImportResult> ImportAsync(string filePath)
    {
        ImportResult result = new();

        using var workbook = new XLWorkbook(filePath);

        var ws = workbook.Worksheet(1);

        using var db = new AppDbContext();

        ProductSyncService sync = new();

        foreach (var row in ws.RowsUsed().Skip(1))
        {
            try
            {
                string code = row.Cell(1).GetString().Trim();

                if (string.IsNullOrWhiteSpace(code))
                    continue;

                if (db.Products.Any(x => x.Code == code))
                    continue;

                string category =
                    row.Cell(3).GetString().Trim();

                if (!db.Categories.Any(x => x.Name == category))
                {
                    db.Categories.Add(new Category
                    {
                        Name = category
                    });

                    db.SaveChanges();
                }

                Product product = new()
                {
                    Code = code,
                    Name = row.Cell(2).GetString(),
                    Category = category,
                    Unit = row.Cell(4).GetString(),
                    BuyPrice = row.Cell(5).GetValue<decimal>(),
                    SellPrice = row.Cell(6).GetValue<decimal>(),
                    Stock = row.Cell(7).GetValue<decimal>(),
                    MinimumStock = row.Cell(8).GetValue<decimal>()
                };

                db.Products.Add(product);

                db.SaveChanges();

                try
                {
                    await sync.UploadAsync(product);
                }
                catch
                {
                    // Tetap lanjut jika cloud gagal
                }

                result.Success++;
            }
            catch (Exception ex)
            {
                result.Failed++;

                result.Errors.Add(ex.Message);
            }
        }

        return result;
    }
}