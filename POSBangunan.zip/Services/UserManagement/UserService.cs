﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.Auth;

namespace POSBangunan.Services.UserManagement;

public class UserService
{
    private readonly AuthService _auth = new();

    public List<User> GetAll()
    {
        using var db = new AppDbContext();

        return db.Users
            .AsNoTracking()
            .OrderBy(x => x.FullName)
            .ToList();
    }

    public List<User> Search(string keyword)
    {
        keyword = keyword.Trim().ToLower();

        using var db = new AppDbContext();

        return db.Users
            .AsNoTracking()
            .Where(x =>
                x.Username.ToLower().Contains(keyword) ||
                x.FullName.ToLower().Contains(keyword))
            .OrderBy(x => x.FullName)
            .ToList();
    }

    public User? GetById(int id)
    {
        using var db = new AppDbContext();

        return db.Users
            .AsNoTracking()
            .FirstOrDefault(x => x.Id == id);
    }

    public bool UsernameExists(string username, int excludeId = 0)
    {
        using var db = new AppDbContext();

        return db.Users.Any(x =>
            x.Username == username &&
            x.Id != excludeId);
    }

    public void Add(
        string username,
        string fullName,
        string password,
        UserRole role)
    {
        if (UsernameExists(username))
            throw new Exception("Username sudah digunakan.");

        using var db = new AppDbContext();

        User user = new()
        {
            Username = username,
            FullName = fullName,
            PasswordHash = Hash(password),
            Role = role,
            IsActive = true,
            CreatedAt = DateTime.Now
        };

        db.Users.Add(user);

        db.SaveChanges();
    }

    public void Update(User user)
    {
        using var db = new AppDbContext();

        User? old = db.Users
            .FirstOrDefault(x => x.Id == user.Id);

        if (old == null)
            throw new Exception("User tidak ditemukan.");

        if (UsernameExists(user.Username, user.Id))
            throw new Exception("Username sudah digunakan.");

        old.Username = user.Username;
        old.FullName = user.FullName;
        old.Role = user.Role;
        old.IsActive = user.IsActive;

        db.SaveChanges();
    }

    public void ResetPassword(
        int userId,
        string password = "admin123")
    {
        _auth.ResetPassword(userId, password);
    }

    public void Delete(int id)
    {
        using var db = new AppDbContext();

        User? user =
            db.Users.FirstOrDefault(x => x.Id == id);

        if (user == null)
            return;

        if (user.Username == "admin")
            throw new Exception(
                "User admin tidak boleh dihapus.");

        db.Users.Remove(user);

        db.SaveChanges();
    }

    private string Hash(string password)
    {
        using var sha =
            System.Security.Cryptography.SHA256.Create();

        byte[] bytes =
            sha.ComputeHash(
                System.Text.Encoding.UTF8.GetBytes(password));

        return Convert.ToHexString(bytes)
            .ToLower();
    }
}