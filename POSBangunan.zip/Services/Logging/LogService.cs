﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Services.Logging;

public static class LogService
{
    private static readonly object Locker = new();

    private static readonly string Folder =
        Path.Combine(
            AppContext.BaseDirectory,
            "Logs");

    public static void Info(string message)
    {
        Write("INFO", message);
    }

    public static void Warning(string message)
    {
        Write("WARNING", message);
    }

    public static void Error(string message)
    {
        Write("ERROR", message);
    }

    public static void Exception(Exception ex)
    {
        Write(
            "EXCEPTION",
            ex.ToString());
    }

    private static void Write(
        string level,
        string message)
    {
        lock (Locker)
        {
            Directory.CreateDirectory(Folder);

            string file =
                Path.Combine(
                    Folder,
                    $"{DateTime.Today:yyyyMMdd}.log");

            StringBuilder sb = new();

            sb.Append(DateTime.Now.ToString(
                "yyyy-MM-dd HH:mm:ss"));

            sb.Append(" | ");

            sb.Append(level);

            sb.Append(" | ");

            sb.AppendLine(message);

            File.AppendAllText(
                file,
                sb.ToString());
        }
    }
}