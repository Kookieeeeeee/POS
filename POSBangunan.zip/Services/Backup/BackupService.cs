﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace POSBangunan.Services.Backup;

public class BackupService
{
    private readonly string _databasePath;

    public BackupService()
    {
        _databasePath = Path.Combine(
            AppContext.BaseDirectory,
            "Database",
            "POSBangunan.db");
    }

    public bool Backup(string destinationFile)
    {
        try
        {
            if (!File.Exists(_databasePath))
                return false;

            string? folder =
                Path.GetDirectoryName(destinationFile);

            if (!string.IsNullOrEmpty(folder))
                Directory.CreateDirectory(folder);

            File.Copy(
                _databasePath,
                destinationFile,
                true);

            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool Restore(string backupFile)
    {
        try
        {
            if (!File.Exists(backupFile))
                return false;

            File.Copy(
                backupFile,
                _databasePath,
                true);

            return true;
        }
        catch
        {
            return false;
        }
    }

    public string GetDefaultBackupName()
    {
        return $"POSBangunan_{DateTime.Now:yyyyMMdd_HHmmss}.db";
    }

    public string GetDatabasePath()
    {
        return _databasePath;
    }
}