﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Services.Product
{
    internal class ProductCodeService
    {
    }
}
