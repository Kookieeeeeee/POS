﻿using POSBangunan.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Services;

public class CartService
{
    public ObservableCollection<CartItem> Items { get; }
        = new();

    public void Add(Product product, decimal qty)
    {
        if (qty <= 0)
            return;

        // Barang non-meteran harus bulat
        if (!product.IsDecimalUnit)
            qty = decimal.Truncate(qty);

        var item = Items.FirstOrDefault(x => x.Product.Id == product.Id);

        if (item == null)
        {
            Items.Add(new CartItem
            {
                Product = product,
                Qty = qty
            });

            return;
        }

        item.Qty += qty;
    }

    public void Add(Product product)
    {
        Add(product, 1);
    }

    public void Increase(Product product)
    {
        var item = Items.FirstOrDefault(x => x.Product.Id == product.Id);

        if (item == null)
            return;

        if (product.IsDecimalUnit)
            item.Qty += 0.5m;
        else
            item.Qty += 1;
    }

    public void Decrease(Product product)
    {
        var item = Items.FirstOrDefault(x => x.Product.Id == product.Id);

        if (item == null)
            return;

        if (product.IsDecimalUnit)
            item.Qty -= 0.5m;
        else
            item.Qty -= 1;

        if (item.Qty <= 0)
            Items.Remove(item);
    }

    public void Remove(Product product)
    {
        var item = Items.FirstOrDefault(x => x.Product.Id == product.Id);

        if (item != null)
            Items.Remove(item);
    }

    public decimal Total()
    {
        return Items.Sum(x => x.SubTotal);
    }

    public decimal TotalItem()
    {
        return Items.Sum(x => x.Qty);
    }

    public void Clear()
    {
        Items.Clear();
    }
}