﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Setting;

public class SettingService
{
    public AppSetting Get()
    {
        using var db = new AppDbContext();

        AppSetting? setting =
            db.AppSettings
              .AsNoTracking()
              .FirstOrDefault();

        if (setting != null)
            return setting;

        setting = new AppSetting();

        db.AppSettings.Add(setting);

        db.SaveChanges();

        return setting;
    }

    public void Save(AppSetting setting)
    {
        using var db = new AppDbContext();

        AppSetting? old =
            db.AppSettings
              .FirstOrDefault();

        if (old == null)
        {
            setting.LastModified = DateTime.Now;

            db.AppSettings.Add(setting);
        }
        else
        {
            old.StoreName = setting.StoreName;
            old.StoreAddress = setting.StoreAddress;
            old.StorePhone = setting.StorePhone;
            old.CashierName = setting.CashierName;

            old.PrinterName = setting.PrinterName;
            old.AutoPrint = setting.AutoPrint;
            old.PrintLogo = setting.PrintLogo;

            old.AutoBackup = setting.AutoBackup;
            old.BackupFolder = setting.BackupFolder;

            old.EnableCloud = setting.EnableCloud;
            old.SupabaseUrl = setting.SupabaseUrl;
            old.SupabaseKey = setting.SupabaseKey;

            old.DarkMode = setting.DarkMode;
            old.Theme = setting.Theme;
            old.CurrencySymbol = setting.CurrencySymbol;

            old.LastModified = DateTime.Now;
        }

        db.SaveChanges();
    }

    public void Reset()
    {
        using var db = new AppDbContext();

        db.AppSettings.RemoveRange(db.AppSettings);

        db.AppSettings.Add(new AppSetting());

        db.SaveChanges();
    }
}