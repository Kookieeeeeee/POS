﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.Inventory;

namespace POSBangunan.Services;

public class OrderService
{
    public Order CreateOrder(
        List<CartItem> cart,
        string cashier)
    {
        using var db = new AppDbContext();

        using var transaction =
            db.Database.BeginTransaction();

        try
        {
            Order order = new()
            {
                InvoiceNumber = GenerateInvoice(db),

                Date = DateTime.Now,

                Cashier = cashier,

                TotalItem = (int)Math.Ceiling(
                    cart.Sum(x => x.Qty)),

                Total = cart.Sum(x => x.SubTotal)
            };

            db.Orders.Add(order);

            db.SaveChanges();

            StockMovementService movement = new();

            foreach (CartItem item in cart)
            {
                Product product =
                    db.Products.First(x =>
                        x.Id == item.Product.Id);

                OrderItem detail = new()
                {
                    OrderId = order.Id,

                    ProductId = product.Id,

                    ProductCode = product.Code,

                    ProductName = product.Name,

                    Unit = product.Unit,

                    BuyPrice = product.BuyPrice,

                    SellPrice = product.SellPrice,

                    Qty = item.Qty,

                    SubTotal = item.SubTotal
                };

                db.OrderItems.Add(detail);

                product.Stock -= item.Qty;

                if (product.Stock < 0)
                    product.Stock = 0;

                movement.AddMovement(
                    product,
                    "OUT",
                    item.Qty,
                    order.InvoiceNumber);
            }

            db.SaveChanges();

            transaction.Commit();
            
            db.Entry(order)
                .Collection(x => x.OrderItems)
                .Load();

            return order;
        }
        catch
        {
            transaction.Rollback();

            throw;
        }
    }

    public Order? GetById(int id)
    {
        using var db = new AppDbContext();

        return db.Orders
                 .Include(x => x.OrderItems)
                 .FirstOrDefault(x => x.Id == id);
    }

    private string GenerateInvoice(AppDbContext db)
    {
        string prefix =
            $"INV-{DateTime.Now:yyyyMMdd}-";

        int lastId =
            db.Orders
              .OrderByDescending(x => x.Id)
              .Select(x => x.Id)
              .FirstOrDefault();

        int number = lastId + 1;

        return prefix +
               number.ToString("0000");
    }

}