﻿using POSBangunan.Services.Sync;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.History;
using POSBangunan.Services.Sync;

namespace POSBangunan.Services.Dashboard;

public class DashboardService
{
    private readonly SalesHistoryService _history = new();

    public DashboardSummary GetSummary()
    {
        using var db = new AppDbContext();

        DashboardSummary summary = new();

        // Total barang
        summary.TotalProduct =
            db.Products.Count();

        // Barang hampir habis
        summary.LowStock =
            db.Products.Count(x =>
                x.Stock <= x.MinimumStock);

        // Penjualan hari ini
        summary.TodaySales =
            _history.GetTodaySales();


        summary.TodayTransaction =
            _history.GetTodayTransaction();

        // Penjualan bulan ini
        summary.MonthSales =
            _history.GetMonthSales();

        summary.MonthTransaction =
            _history.GetMonthTransaction();

        // Transaksi terakhir
        summary.LastTransaction =
            _history.GetLastTransaction();

        // 5 transaksi terakhir
        summary.RecentOrders =
            db.Orders
              .AsNoTracking()
              .OrderByDescending(x => x.Date)
              .Take(5)
              .ToList();

        //
        // CLOUD
        // (sementara hardcode dulu,
        // nanti kita sambungkan ke Supabase)
        //

        summary.CloudConnected = true;

        summary.CloudProduct =
            summary.TotalProduct;

        summary.LastSync =
            DateTime.Now;

        return summary;
    }
}