﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.History;

public class SalesHistoryService
{
    public List<Order> GetAll()
    {
        using var db = new AppDbContext();

        return db.Orders
                 .AsNoTracking()
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public List<Order> Search(string keyword)
    {
        using var db = new AppDbContext();

        keyword = keyword.Trim().ToLower();

        return db.Orders
                 .AsNoTracking()
                 .Where(x =>
                     x.InvoiceNumber.ToLower().Contains(keyword) ||
                     x.Cashier.ToLower().Contains(keyword))
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public List<OrderItem> GetItems(int orderId)
    {
        using var db = new AppDbContext();

        return db.OrderItems
                 .AsNoTracking()
                 .Where(x => x.OrderId == orderId)
                 .OrderBy(x => x.ProductName)
                 .ToList();
    }

    public List<Order> Filter(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.Orders
                 .AsNoTracking()
                 .Where(x =>
                     x.Date >= from &&
                     x.Date < until)
                 .OrderByDescending(x => x.Date)
                 .ToList();
    }

    public bool Delete(int orderId)
    {
        using var db = new AppDbContext();

        using var transaction =
            db.Database.BeginTransaction();

        try
        {
            Order? order =
                db.Orders.FirstOrDefault(x => x.Id == orderId);

            if (order == null)
                return false;

            var items =
                db.OrderItems
                  .Where(x => x.OrderId == orderId)
                  .ToList();

            foreach (var item in items)
            {
                var product =
                    db.Products.FirstOrDefault(x =>
                        x.Id == item.ProductId);

                if (product != null)
                {
                    product.Stock += item.Qty;
                }
            }

            db.OrderItems.RemoveRange(items);

            db.Orders.Remove(order);

            db.SaveChanges();

            transaction.Commit();

            return true;
        }
        catch
        {
            transaction.Rollback();

            return false;
        }
    }

    public decimal GetTotalSales(DateTime start, DateTime end)
    {
        using var db = new AppDbContext();

        DateTime from = start.Date;
        DateTime until = end.Date.AddDays(1);

        return db.Orders
            .Where(x => x.Date >= from && x.Date < until)
            .AsEnumerable()
            .Sum(x => x.Total);
    }
    public decimal GetTodaySales()
    {
        using var db = new AppDbContext();

        DateTime today = DateTime.Today;

        return db.Orders
                 .AsEnumerable()
                 .Where(x => x.Date.Date == today)
                 .Sum(x => x.Total);
    }

    public int GetTodayTransaction()
    {
        using var db = new AppDbContext();

        DateTime today = DateTime.Today;

        return db.Orders
                 .Count(x => x.Date.Date == today);
    }

    public decimal GetMonthSales()
    {
        using var db = new AppDbContext();

        int month = DateTime.Now.Month;
        int year = DateTime.Now.Year;

        return db.Orders
                 .AsEnumerable()
                 .Where(x =>
                     x.Date.Month == month &&
                     x.Date.Year == year)
                 .Sum(x => x.Total);
    }

    public int GetMonthTransaction()
    {
        using var db = new AppDbContext();

        int month = DateTime.Now.Month;
        int year = DateTime.Now.Year;

        return db.Orders
                 .Count(x =>
                     x.Date.Month == month &&
                     x.Date.Year == year);
    }

    public Order? GetLastTransaction()
    {
        using var db = new AppDbContext();

        return db.Orders
                 .OrderByDescending(x => x.Date)
                 .FirstOrDefault();
    }
}