﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.Sync;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Services;

public class ProductService
{
    public List<Product> GetAll()
    {
        using var db = new AppDbContext();

        return db.Products
                 .AsNoTracking()
                 .OrderBy(x => x.Name)
                 .ToList();
    }

    public Product? GetById(int id)
    {
        using var db = new AppDbContext();

        return db.Products
                 .AsNoTracking()
                 .FirstOrDefault(x => x.Id == id);
    }

    public bool CodeExists(string code)
    {
        using var db = new AppDbContext();

        return db.Products.Any(x =>
            x.Code.ToLower() == code.ToLower());
    }

    public bool CodeExists(string code, int productId)
    {
        using var db = new AppDbContext();

        return db.Products.Any(x =>
            x.Code.ToLower() == code.ToLower() &&
            x.Id != productId);
    }

    public List<Product> Search(string keyword)
    {
        using var db = new AppDbContext();

        IQueryable<Product> query = db.Products.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            keyword = keyword.Trim().ToLower();

            query = query.Where(x =>

                x.Name.ToLower().Contains(keyword)

                ||

                x.Code.ToLower().Contains(keyword)

                ||

                x.Category.ToLower().Contains(keyword)

                ||

                x.Unit.ToLower().Contains(keyword));
        }

        return query
            .OrderBy(x => x.Name)
            .ToList();
    }

    public async Task<bool> AddAsync(Product product)
    {
        using var db = new AppDbContext();

        db.Products.Add(product);

        db.SaveChanges();

        try
        {
            ProductSyncService sync = new();

            await sync.UploadAsync(product);

            return true;
        }
        catch
        {
            // SQLite tetap berhasil
            return false;
        }
    }

    public async Task<bool> UpdateAsync(Product product)
    {
        using var db = new AppDbContext();

        db.Products.Update(product);

        db.SaveChanges();

        try
        {
            ProductSyncService sync = new();

            await sync.UploadAsync(product);

            return true;
        }
        catch
        {
            return false;
        }
    }
    public async Task<bool> DeleteAsync(int id)
    {
        using var db = new AppDbContext();

        var product = db.Products.Find(id);

        if (product == null)
            return false;

        string code = product.Code;

        db.Products.Remove(product);

        db.SaveChanges();

        try
        {
            ProductSyncService sync = new();

            //await sync.DeleteAsync(code);

            return true;
        }
        catch
        {
            return false;
        }
    }

    public int TotalProduct()
    {
        using var db = new AppDbContext();

        return db.Products.Count();
    }

    public int TotalLowStock()
    {
        using var db = new AppDbContext();

        return db.Products.Count(x =>
            x.Stock <= x.MinimumStock);
    }
    public string GenerateCode(string category)
    {
        using var db = new AppDbContext();

        string prefix = category.Trim().ToUpper() switch
        {
            "SEMEN" => "SEM",
            "CAT" => "CAT",
            "BESI" => "BES",
            "PIPA" => "PIP",
            "KABEL" => "KBL",
            "KERAMIK" => "KER",
            "BAUT" => "BAT",
            "PAKU" => "PAK",
            "PASIR" => "PSR",
            "BATAKO" => "BTK",
            _ => "BRG"
        };

        int lastNumber = db.Products
            .Where(x => x.Code.StartsWith(prefix))
            .Select(x => x.Code)
            .AsEnumerable()
            .Select(code =>
            {
                string number = code.Substring(prefix.Length);

                return int.TryParse(number, out int n) ? n : 0;
            })
            .DefaultIfEmpty()
            .Max();

        return $"{prefix}{(lastNumber + 1):D4}";
    }
}