﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;
using POSBangunan.Services.Auth;

namespace POSBangunan.Services.Audit;

public class AuditService
{
    public void Log(
        string module,
        string action,
        string description)
    {
        using var db = new AppDbContext();

        AuditLog log = new()
        {
            Time = DateTime.Now,

            Username =
                SessionManager.IsLoggedIn
                    ? SessionManager.Username
                    : "SYSTEM",

            Module = module,

            Action = action,

            Description = description,

            ComputerName = Environment.MachineName,

            IpAddress = ""
        };

        db.AuditLogs.Add(log);

        db.SaveChanges();
    }

    public List<AuditLog> GetAll()
    {
        using var db = new AppDbContext();

        return db.AuditLogs
                 .AsNoTracking()
                 .OrderByDescending(x => x.Time)
                 .ToList();
    }

    public List<AuditLog> Search(string keyword)
    {
        keyword = keyword.ToLower();

        using var db = new AppDbContext();

        return db.AuditLogs
                 .AsNoTracking()
                 .Where(x =>
                     x.Username.ToLower().Contains(keyword) ||
                     x.Module.ToLower().Contains(keyword) ||
                     x.Action.ToLower().Contains(keyword) ||
                     x.Description.ToLower().Contains(keyword))
                 .OrderByDescending(x => x.Time)
                 .ToList();
    }

    public List<AuditLog> GetByDate(
        DateTime start,
        DateTime end)
    {
        using var db = new AppDbContext();

        return db.AuditLogs
                 .AsNoTracking()
                 .Where(x =>
                     x.Time >= start &&
                     x.Time <= end)
                 .OrderByDescending(x => x.Time)
                 .ToList();
    }

    public void Clear()
    {
        using var db = new AppDbContext();

        db.AuditLogs.RemoveRange(
            db.AuditLogs);

        db.SaveChanges();
    }
}