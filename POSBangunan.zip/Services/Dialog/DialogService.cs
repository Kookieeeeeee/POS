﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace POSBangunan.Services.Dialog;

public static class DialogService
{
    public static void Info(
        string message,
        string title = "POS Bangunan")
    {
        MessageBox.Show(
            message,
            title,
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    public static void Warning(
        string message,
        string title = "POS Bangunan")
    {
        MessageBox.Show(
            message,
            title,
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
    }

    public static void Error(
        string message,
        string title = "POS Bangunan")
    {
        MessageBox.Show(
            message,
            title,
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }

    public static bool Question(
        string message,
        string title = "POS Bangunan")
    {
        return MessageBox.Show(
            message,
            title,
            MessageBoxButton.YesNo,
            MessageBoxImage.Question)
            == MessageBoxResult.Yes;
    }

    public static bool ConfirmDelete(
        string objectName)
    {
        return Question(
            $"Apakah Anda yakin ingin menghapus {objectName}?");
    }

    public static void Success(string message)
    {
        Info(message, "Berhasil");
    }

    public static void Failed(string message)
    {
        Error(message, "Gagal");
    }
}