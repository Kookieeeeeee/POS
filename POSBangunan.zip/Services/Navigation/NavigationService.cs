﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace POSBangunan.Services.Navigation;

public static class NavigationService
{
    private static ContentControl? _content;

    public static void Initialize(ContentControl content)
    {
        _content = content;
    }

    public static void Navigate(UserControl view)
    {
        if (_content == null)
            return;

        _content.Content = view;
    }

    public static void Clear()
    {
        if (_content != null)
            _content.Content = null;
    }
}