﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Sync;

public class ProductSyncService
{
    private readonly SupabaseService _supabase = new();

    public async Task<bool> UploadAsync(Product product)
    {
        return await _supabase.UploadProductAsync(product);
    }

    public async Task<int> UploadAllAsync()
    {
        using var db = new AppDbContext();

        List<Product> products =
            await db.Products
                    .AsNoTracking()
                    .ToListAsync();

        int success = 0;

        foreach (Product product in products)
        {
            bool uploaded =
                await _supabase.UploadProductAsync(product);

            if (uploaded)
                success++;
        }

        return success;
    }

    public async Task<int> DownloadAsync()
    {
        using var db = new AppDbContext();

        List<Product> cloudProducts =
            await _supabase.DownloadProductsAsync();

        int total = 0;

        foreach (Product cloud in cloudProducts)
        {
            Product? local =
                await db.Products
                        .FirstOrDefaultAsync(x =>
                            x.Code == cloud.Code);

            if (local == null)
            {
                db.Products.Add(cloud);
            }
            else
            {
                local.Name = cloud.Name;
                local.Category = cloud.Category;
                local.Unit = cloud.Unit;
                local.BuyPrice = cloud.BuyPrice;
                local.SellPrice = cloud.SellPrice;
                local.Stock = cloud.Stock;
                local.MinimumStock = cloud.MinimumStock;
                local.ImagePath = cloud.ImagePath;
            }

            total++;
        }

        await db.SaveChangesAsync();

        return total;
    }
}