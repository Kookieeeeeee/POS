﻿using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Sync;

public class CloudSyncService
{
    private readonly SupabaseService _supabase = new();

    public async Task<CloudStatus> GetStatusAsync()
    {
        CloudStatus status = new();

        using var db = new AppDbContext();

        status.LocalProduct = db.Products.Count();

        status.LocalOrder = db.Orders.Count();

        try
        {
            status.Connected =
                await _supabase.TestConnectionAsync();

            if (status.Connected)
            {
                status.CloudProduct =
                    await _supabase.GetProductCountAsync();

                // Order tidak menggunakan Supabase
                status.CloudOrder = 0;
            }
        }
        catch
        {
            status.Connected = false;
        }

        status.PendingUpload = 0;
        status.FailedUpload = 0;
        status.LastSync = DateTime.Now;

        return status;
    }

    public async Task<bool> UploadAllAsync()
    {
        try
        {
            ProductSyncService product = new();

            await product.UploadAllAsync();

            return true;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> DownloadAllAsync()
    {
        try
        {
            ProductDownloadService product = new();

            await product.DownloadAsync();

            return true;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> FullSyncAsync()
    {
        bool upload =
            await UploadAllAsync();

        if (!upload)
            return false;

        bool download =
            await DownloadAllAsync();

        return download;
    }
}