﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using POSBangunan.Models;

namespace POSBangunan.Services.Sync;

public class SupabaseService
{
    private readonly HttpClient _http = new();

    public SupabaseService()
    {
        _http.BaseAddress = new Uri(
            $"{SupabaseConfig.Url}/rest/v1/");

        _http.DefaultRequestHeaders.Clear();

        _http.DefaultRequestHeaders.Add(
            "apikey",
            SupabaseConfig.ApiKey);

        _http.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue(
                "Bearer",
                SupabaseConfig.ApiKey);

        _http.DefaultRequestHeaders.Add(
            "Prefer",
            "return=representation");
    }

    //=================================================
    // CONNECTION
    //=================================================

    public async Task<bool> TestConnectionAsync()
    {
        try
        {
            HttpResponseMessage response =
                await _http.GetAsync(
                    "categories?select=id&limit=1");

            if (!response.IsSuccessStatusCode)
            {
                string error =
                    await response.Content.ReadAsStringAsync();

                System.Diagnostics.Debug.WriteLine(error);

                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(ex.Message);

            return false;
        }
    }

    //=================================================
    // PRODUCT
    //=================================================

    public async Task<List<Product>> DownloadProductsAsync()
    {
        HttpResponseMessage response =
            await _http.GetAsync(
                "products?select=*");

        if (!response.IsSuccessStatusCode)
            return new();

        string json =
            await response.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<List<Product>>(
            json,
            new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }) ?? new();
    }

    public async Task<bool> UploadProductAsync(Product product)
    {
        string json =
            JsonSerializer.Serialize(new
            {
                code = product.Code,
                name = product.Name,
                category = product.Category,
                unit = product.Unit,
                buy_price = product.BuyPrice,
                sell_price = product.SellPrice,
                stock = product.Stock,
                minimum_stock = product.MinimumStock,
                image_file = product.ImagePath,
                updated_at = DateTime.UtcNow
            });

        StringContent content =
            new(
                json,
                Encoding.UTF8,
                "application/json");

        HttpResponseMessage response =
            await _http.PostAsync(
                "products",
                content);

        return response.IsSuccessStatusCode;
    }

    public async Task<int> GetProductCountAsync()
    {
        HttpRequestMessage request =
            new(HttpMethod.Get,
                "products?select=id");

        request.Headers.Add(
            "Prefer",
            "count=exact");

        HttpResponseMessage response =
            await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
            return 0;

        if (!response.Headers.TryGetValues(
            "Content-Range",
            out var values))
            return 0;

        string value = values.First();

        int index = value.IndexOf('/');

        if (index < 0)
            return 0;

        return int.Parse(
            value[(index + 1)..]);
    }

    //=================================================
    // CATEGORY
    //=================================================

    public async Task<int> GetCategoryCountAsync()
    {
        HttpRequestMessage request =
            new(HttpMethod.Get,
                "categories?select=id");

        request.Headers.Add(
            "Prefer",
            "count=exact");

        HttpResponseMessage response =
            await _http.SendAsync(request);

        if (!response.IsSuccessStatusCode)
            return 0;

        if (!response.Headers.TryGetValues(
            "Content-Range",
            out var values))
            return 0;

        string value = values.First();

        int index = value.IndexOf('/');

        if (index < 0)
            return 0;

        return int.Parse(
            value[(index + 1)..]);
    }
}