﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSBangunan.Services.Sync;

public static class SupabaseConfig
{
    public const string Url =
        "https://kxvwbugwlezbycvhfdft.supabase.co";

    public const string ApiKey =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt4dndidWd3bGV6YnljdmhmZGZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI4NzUyMDEsImV4cCI6MjA5ODQ1MTIwMX0.hJ43Fq5NTsvkfvbdFxmwXPkq4nVnwAIJINlo5ulWolM";

    public static string ProductsEndpoint =>
        $"{Url}/rest/v1/products";
}