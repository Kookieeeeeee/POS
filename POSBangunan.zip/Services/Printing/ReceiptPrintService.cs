﻿using POSBangunan.Models;
using System.Drawing;
using System.Drawing.Printing;

namespace POSBangunan.Services.Printing;

public class ReceiptPrinterService
{
    private readonly PrintService _builder = new();

    public void Print(Order order, string? printerName = null)
    {
        string receipt = _builder.BuildReceipt(order);

        PrintDocument document = new();

        if (!string.IsNullOrWhiteSpace(printerName))
            document.PrinterSettings.PrinterName = printerName;

        document.PrintPage += (sender, e) =>
        {
            using Font font = new("Consolas", 10);

            e.Graphics.DrawString(
                receipt,
                font,
                Brushes.Black,
                new RectangleF(
                    5,
                    5,
                    e.MarginBounds.Width,
                    e.MarginBounds.Height));
        };

        document.Print();
    }

    public List<string> GetInstalledPrinters()
    {
        List<string> printers = new();

        foreach (string printer in PrinterSettings.InstalledPrinters)
        {
            printers.Add(printer);
        }

        return printers;
    }

    public string GetDefaultPrinter()
    {
        PrintDocument doc = new();

        return doc.PrinterSettings.PrinterName;
    }
}