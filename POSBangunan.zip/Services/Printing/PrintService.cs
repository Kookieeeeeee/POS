﻿using POSBangunan.Models;
using System.Text;

namespace POSBangunan.Services.Printing;

public class PrintService
{
    public string BuildReceipt(Order order)
    {
        StringBuilder sb = new();

        sb.AppendLine(Center("TB BINTANG REZEKI"));
        sb.AppendLine(Center("TOKO BAHAN BANGUNAN"));
        sb.AppendLine(new string('-', 32));

        sb.AppendLine($"Invoice : {order.InvoiceNumber}");
        sb.AppendLine($"Tanggal : {order.Date:dd/MM/yyyy HH:mm}");
        sb.AppendLine($"Kasir   : {order.Cashier}");

        sb.AppendLine(new string('-', 32));

        foreach (var item in order.OrderItems)
        {
            sb.AppendLine(item.ProductName);

            sb.AppendLine(
                $"{item.Qty:0.##} x {item.SellPrice:N0}");

            sb.AppendLine(
                AlignRight(
                    $"Rp {item.SubTotal:N0}"));
        }

        sb.AppendLine(new string('-', 32));

        sb.AppendLine(
            AlignRight($"TOTAL : Rp {order.Total:N0}"));

        sb.AppendLine();

        sb.AppendLine(Center("Terima Kasih"));

        sb.AppendLine(Center("Belanja Kembali"));

        return sb.ToString();
    }

    private string Center(string text)
    {
        int width = 32;

        if (text.Length >= width)
            return text;

        int left =
            (width - text.Length) / 2;

        return new string(' ', left) + text;
    }

    private string AlignRight(string text)
    {
        int width = 32;

        if (text.Length >= width)
            return text;

        return new string(
            ' ',
            width - text.Length) + text;
    }
}