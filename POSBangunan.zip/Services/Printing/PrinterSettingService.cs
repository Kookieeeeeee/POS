﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Database;
using POSBangunan.Models;

namespace POSBangunan.Services.Printing;

public class PrinterSettingService
{
    public PrinterSetting Get()
    {
        using var db = new AppDbContext();

        PrinterSetting? setting =
            db.PrinterSettings
              .AsNoTracking()
              .FirstOrDefault();

        if (setting != null)
            return setting;

        // Default setting pertama kali
        setting = new PrinterSetting
        {
            PrinterName = "",
            PaperWidth = 80,
            AutoPrint = true,
            OpenCashDrawer = false,
            UpdatedAt = DateTime.Now
        };

        db.PrinterSettings.Add(setting);

        db.SaveChanges();

        return setting;
    }

    public void Save(PrinterSetting setting)
    {
        using var db = new AppDbContext();

        PrinterSetting? existing =
            db.PrinterSettings
              .FirstOrDefault();

        if (existing == null)
        {
            setting.UpdatedAt = DateTime.Now;

            db.PrinterSettings.Add(setting);
        }
        else
        {
            existing.PrinterName = setting.PrinterName;
            existing.PaperWidth = setting.PaperWidth;
            existing.AutoPrint = setting.AutoPrint;
            existing.OpenCashDrawer = setting.OpenCashDrawer;
            existing.UpdatedAt = DateTime.Now;
        }

        db.SaveChanges();
    }

    public string GetPrinterName()
    {
        return Get().PrinterName;
    }

    public int GetPaperWidth()
    {
        return Get().PaperWidth;
    }

    public bool IsAutoPrint()
    {
        return Get().AutoPrint;
    }

    public bool IsCashDrawerEnabled()
    {
        return Get().OpenCashDrawer;
    }
}