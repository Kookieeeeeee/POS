﻿using Microsoft.EntityFrameworkCore;

namespace POSBangunan.Database;

public static class DatabaseInitializer
{
    public static void Initialize()
    {
        using var db = new AppDbContext();

        db.Database.Migrate();

       DatabaseSeeder.Seed(db);
    }
}