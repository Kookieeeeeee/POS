﻿using POSBangunan.Models;
using POSBangunan.Services;
using POSBangunan.Services.Auth;
using System;
using System.Linq;

namespace POSBangunan.Database;

public static class DatabaseSeeder
{
    public static void Seed(AppDbContext db)
    {
        SeedAdmin(db);
        SeedAppSetting(db);
        SeedPrinter(db);

        db.SaveChanges();
    }

    private static void SeedAdmin(AppDbContext db)
    {
        if (db.Users.Any())
            return;

        db.Users.Add(new User
        {
            Username = "admin",
            FullName = "Administrator",
            PasswordHash = AuthService.HashPassword("admin123"),
            Role = UserRole.Admin,
            IsActive = true,
            CreatedAt = DateTime.Now
        });
    }

    private static void SeedAppSetting(AppDbContext db)
    {
        if (db.AppSettings.Any())
            return;

        db.AppSettings.Add(new AppSetting
        {
            StoreName = "POS Bangunan",
            StoreAddress = "",
            StorePhone = "",
            CashierName = "Administrator",

            AutoPrint = true,
            PrintLogo = false,

            AutoBackup = false,
            BackupFolder = "",

            EnableCloud = true,
            SupabaseUrl = "",
            SupabaseKey = "",

            DarkMode = false,
            Theme = "Blue",
            CurrencySymbol = "Rp",

            LastModified = DateTime.Now
        });
    }

    private static void SeedPrinter(AppDbContext db)
    {
        if (db.PrinterSettings.Any())
            return;

        db.PrinterSettings.Add(new PrinterSetting
        {
            PrinterName = "",
            PaperWidth = 80,
            AutoPrint = true,
            OpenCashDrawer = false,
            UpdatedAt = DateTime.Now
        });
    }
}