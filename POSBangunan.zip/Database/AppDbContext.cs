﻿using Microsoft.EntityFrameworkCore;
using POSBangunan.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace POSBangunan.Database;

public class AppDbContext : DbContext
{
    public DbSet<Product> Products => Set<Product>();

    public DbSet<Category> Categories => Set<Category>();

    public DbSet<Order> Orders => Set<Order>();

    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    public DbSet<StockMovement> StockMovements => Set<StockMovement>();

    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    public DbSet<AppSetting> AppSettings => Set<AppSetting>();

    public DbSet<User> Users => Set<User>();

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public bool IsDeleted { get; set; } = false;

    public Guid CloudId { get; set; } = Guid.NewGuid();

    public DbSet<SyncMetadata> SyncMetadata =>
    Set<SyncMetadata>();

    // ==========================
    // BARU
    // ==========================

    public DbSet<PrinterSetting> PrinterSettings => Set<PrinterSetting>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            string dbPath = Path.Combine(
                AppContext.BaseDirectory,
                "Database",
                "POSBangunan.db");

            Directory.CreateDirectory(
                Path.GetDirectoryName(dbPath)!);

            optionsBuilder.UseSqlite(
                $"Data Source={dbPath}");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Product>()
            .HasIndex(x => x.Code)
            .IsUnique();

        modelBuilder.Entity<Category>()
            .HasIndex(x => x.Name)
            .IsUnique();

        modelBuilder.Entity<Order>()
            .HasMany(x => x.OrderItems)
            .WithOne(x => x.Order)
            .HasForeignKey(x => x.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Product>()
            .Property(x => x.BuyPrice)
            .HasPrecision(18, 2);

        modelBuilder.Entity<Product>()
            .Property(x => x.SellPrice)
            .HasPrecision(18, 2);

        modelBuilder.Entity<Product>()
            .Property(x => x.Stock)
            .HasPrecision(18, 2);

        modelBuilder.Entity<Product>()
            .Property(x => x.MinimumStock)
            .HasPrecision(18, 2);

        modelBuilder.Entity<OrderItem>()
            .Property(x => x.BuyPrice)
            .HasPrecision(18, 2);

        modelBuilder.Entity<OrderItem>()
            .Property(x => x.SellPrice)
            .HasPrecision(18, 2);

        modelBuilder.Entity<OrderItem>()
            .Property(x => x.Qty)
            .HasPrecision(18, 2);

        modelBuilder.Entity<OrderItem>()
            .Property(x => x.SubTotal)
            .HasPrecision(18, 2);

        modelBuilder.Entity<StockMovement>()
            .Property(x => x.Qty)
            .HasPrecision(18, 2);

        modelBuilder.Entity<StockMovement>()
            .Property(x => x.Balance)
            .HasPrecision(18, 2);
    }
}